<template>
  <div class="wrapper" id="app">
    <router-view></router-view>
  </div>
</template>

<script>
export default {
  name: 'App',
  data () {
    let data = {}
    return data
  },
  mounted () {},
  methods: {}
}
</script>
<style lang="scss">
@import "sass/main.scss";
</style>
