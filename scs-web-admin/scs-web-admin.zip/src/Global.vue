<script type="text/javascript">
// const serverPathScsDI = 'http://210.83.216.71:1001/api/scs-service-scsdi'
// const serverPathSys = 'http://210.83.216.71:1001/api/scs-service-system'
// const serverPathFile = 'http://210.83.216.71:1001/zuul/api/scs-service-filemanagement'
// const serverPathUser = 'http://210.83.216.71:1001/api/scs-service-usermanagement'
// const serverPathMsgCenter = 'http://210.83.216.71:1001/api/scs-service-messagecenter'
const serverPathScsDI = 'http://localhost:8769/api/scs-service-scsdi'
const serverPathSys = 'http://localhost:8769/api/scs-service-system'
const serverPathFile = 'http://localhost:8769/zuul/api/scs-service-filemanagement'
const serverPathUser = 'http://localhost:8769/api/scs-service-usermanagement'
const serverPathMsgCenter = 'http://localhost:8769/api/scs-service-messagecenter'

const loadingshow = false
const url = {
  parameters: {
    getObjectType: '/getObjectType', // 获取对象类型
    getCompanyTable: '/getCompanyTable', // 获取对象列表
    runIntelligentAnalisys: '/runindexanalisys', // 执行智能分析
    runBenchmarkingAnalisys: '/runBenchmarkingAnalisys', // 执行对标分析
    getTasks: '/getTasks', // 查询任务结果
    getIndexsTree: '/indexs/tree', // 查询指标树数据
    getFunctionTree: '/indexs/functiontree' // 函数计算指标
  },
  indexType: {
    deleteIndexTypeById: '/scsindextype/id/{id}', // 根据Id删除数据
    newIndexType: '/scsindextype', // 新增指标类型
    modifyIndexType: '/scsindextype', // 修改指标类型信息
    getIndexTypeById: '/scsindextype/id/{id}', // 修改指标类型信息
    getAllByTypeid: '/scsindextypes/all/typeid/{typeid}' // 根据分析对象类型查询所有指标类型
  },
  objectType: {
    deleteObjectTypeById: '/scsobjecttype/id/{id}', // 根据Id删除数据
    newObjectType: '/scsobjecttype', // 新增对象类型
    modifyObjectType: '/scsobjecttype', // 修改对象类型信息
    getObjectTypeById: '/scsobjecttype/id/{id}', // 根据Id查询对象类型信息
    getAllObjectTypes: '/scsobjecttypes/all', // 查询所有对象类型数据
    getObjectTypesBySearch: '/scsobjecttypes/all/search', // 根据条件查询分析对象类型
    getPagerObjectTypesBySearch: '/scsobjecttypes/all/search/pager' // 根据条件查询分析对象类型
  },
  unitType: {
    deleteUnitTypeById: '/scsunittype/id/{id}', // 根据Id删除数据
    newUnitType: '/scsunittype', // 新增单位类型
    modifyUnitType: '/scsunittype', // 修改单位类型信息
    getUnitTypeById: '/scsunittype/id/{id}', // 根据Id查询单位类型信息
    getAllUnitTypes: '/scsunittypes/all', // 查询所有单位类型数据
    getUnitTypesBySearch: '/scsunittypes/all/search', // 根据条件查询单位类型
    getPagerUnitTypesBySearch: '/scsunittypes/all/search/pager' // 根据条件查询单位类型
  },
  selector: {
    deleteSelectorById: '/scsselector/id/{id}', // 根据Id删除数据
    newSelector: '/scsselector', // 新增选择器
    modifySelector: '/scsselector', // 修改选择器信息
    getSelectorById: '/scsselector/id/{id}', // 根据Id查询选择器信息
    getAllSelectors: '/scsselectors/all', // 查询所有选择器数据
    getSelectorsBySearch: '/scsselectors/all/search', // 根据条件查询分析选择器
    getPagerSelectorsBySearch: '/scsselectors/all/search/pager' // 根据条件查询分析选择器
  },
  scsObject: {
    deleteObjectById: '/scsobject/id/{id}', // 根据Id删除数据
    newObject: '/scsobject', // 新增对象
    modifyObject: '/scsobject', // 修改对象信息
    getObjectById: '/scsobject/id/{id}', // 根据Id查询对象信息
    getObjectsBySearch: '/scsobjects/all/search', // 根据条件查询分析对象
    getPagerObjectsBySearch: '/scsobjects/all/search/pager' // 根据条件查询分析对象
  },
  functions: {
    newFunction: '/sysfunction', // 新增资源信息
    modifyFunction: '/sysfunction', // 新增资源信息
    deleteFunction: '/sysfunction/id/{id}', // 删除资源信息
    getFunctionById: '/sysfunction/id/{id}', // 根据资源ID查询资源信息
    getFunctionRoleBySearch: '/sysfunctions/functionrole/search', // 根据查询条件查询资源与角色关联信息
    getAllEnableFunctionByType: '/sysfunctions/allenable/functiontype/{functionType}', // 根据资源类型查询所有可用资源信息
    getMenuByOrigin: '/sysfunctions/menu/origin', // 根据个人权限获取菜单
    getAllFunctionByTypeAndParentId: '/sysfunctions/all/functiontype/{functionType}/parentid/{parentId}', // 根据资源类型和父级Id查询所有可用资源信息
    getAllFunctionByType: '/sysfunctions/all/functiontype/{functionType}' // 根据资源类型查询所有资源信息
  },
  user: {
    getPagerUsersBySearch: '/sysusers/all/search/pager', // 根据条件查询用户列表信息（分页）
    getPagerEnableUsersBySearch: '/sysusers/allenable/search/pager', // 根据条件查询可用用户列表信息（分页）
    getPagerUndeletedUsersBySearch: '/sysusers/allundeleted/search/pager', // 根据条件查询未删除用户列表信息（分页）
    getPagerUserRolesBySearch: '/sysusers/userrole/search/pager', // 根据查询条件查询用户与角色信息（分页）
    getUserById: '/sysuser/id/{id}', // 根据条件查询用户列表信息（分页）
    deleteUserById: '/sysuser/id/{id}', // 根据Id删除数据
    resetPassword: '/sysuser/resetpassword/id/{id}', // 根据Id重置用户密码
    newUser: '/sysuser', // 新增用户
    modifyUser: '/sysuser', // 修改用户信息
    userLogin: '/sysuser/checklogin' // 用户登录
  },
  role: {
    getPagerRolesBySearch: '/sysroles/all/search/pager', // 根据条件查询用户列表信息（分页）
    getPagerEnableRolesBySearch: '/sysroles/allenable/search/pager', // 根据条件查询可用用户列表信息（分页）
    getPagerUndeletedRolesBySearch: '/sysroles/allundeleted/search/pager', // 根据条件查询未删除用户列表信息（分页）
    getRoleById: '/sysrole/id/{id}', // 根据条件查询用户列表信息（分页）
    deleteRoleById: '/sysrole/id/{id}', // 根据Id删除数据
    newRole: '/sysrole', // 新增用户
    modifyRole: '/sysrole' // 修改用户信息
  },
  userRoleRelationship: {
    newRelation: '/sysuserrole', // 添加用户与角色关系
    deleteRelationById: '/sysuserrole/id/{id}' // 根据关系主键删除用户与角色关系
  },
  functionRoleRelationship: {
    newRelation: '/sysrolefunction', // 添加资源与角色关系
    deleteRelationById: '/sysrolefunction/id/{id}' // 根据关系主键删除资源与角色关系
  }
}
const ScsDefault = {
  mainPath: '/intelligent-analysis', // 首页地址
  userLogoImg: 'static/img/default-user-logo.png' // 用户头像默认图片地址
}
export default {
  serverPathScsDI,
  serverPathSys,
  serverPathFile,
  serverPathUser,
  serverPathMsgCenter,
  loadingshow,
  url,
  ScsDefault
}
</script>
