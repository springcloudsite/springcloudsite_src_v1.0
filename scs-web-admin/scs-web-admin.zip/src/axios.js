import axios from 'axios'
import global from './Global'
import router from './routes'
import userAuthentication from './userAuthentication'
// axios 配置
// axios.defaults.withCredentials = true // 使请求携带cookie
axios.defaults.timeout = 5000
axios.defaults.headers.post['Content-Type'] = 'application/json'
// axios.defaults.headers.common['Authorization'] = 'bearer '
// axios.defaults.baseURL = '/wh'
console.log('加载了+axios')

let _tokenHeader = 'authorization' // 存放token的header名称

let ignoreRouter = function (name) {
  // 判断路由屏蔽
  // name为router中定义的name属性
  let result = true
  // if (name === 'user-register') {
  //   result = true
  // }
  return result
}

let urlRender = function (url, params) {
  // 添加字符串转译功能
  // 例 "{name}很厉name害，才{age}岁。".render({name:'admin',age:'15'})
  params = params || {}
  return url.replace(/\{(.*?)\}/g, function (word, key) {
    return params[$.trim(key)] || ''
  })
}
let getCookieByKey = function (key) {
  // 获取cookie值
  let arr = []
  let reg = new RegExp('(^| )' + key + '=([^;]*)(;|$)')
  arr = document.cookie.match(reg)
  if (arr) {
    return unescape(arr[2])
  } else {
    return ''
  }
}

axios.interceptors.request.use(function (config) {
  let headers = config.headers.common
  if (!headers) {
    headers = {}
  }
  let token = getCookieByKey('user-token') || ''
  headers[_tokenHeader] = token
  config.headers.common = headers

  if (!ignoreRouter(router.history.current.name)) {
    // 如果没有token取消操作
    switch (config.method.toUpperCase()) {
      case 'PUT':
      case 'POST':
      case 'PATCH':
      case 'DELETE': {
        if (!token) {
          let error = {
            response: {
              data: {
                errorCode: 'messages.loginBefore',
                errorMessage: '您还未登录，请先登录系统'
              },
              status: 403
            }
          }
          throw error
        }
      }
    }
  }
  // 动态拼接url
  config.url = urlRender(config.url, config.urlParams)
  // console.log('->AXIOS拦截器请求开始')
  // console.log(global.loadingshow)
  global.loadingshow = true
  return config
}, function (err) {
  return Promise.reject(err)
})

// http response 拦截器
axios.interceptors.response.use(
  response => {
    let auth = response.headers[_tokenHeader] || ''
    if (auth) {
      let exp = new Date()
      exp.setTime(exp.getTime() + 30 * 60 * 1000)
      if (document.domain.indexOf('tgcw.net.cn') > -1) {
        document.cookie = 'user-token=' + auth + ';domain=tgcw.net.cn;path=/;expires=' + exp.toGMTString()
      } else {
        document.cookie = 'user-token=' + auth + ';path=/;expires=' + exp.toGMTString()
      }
    }
    return response
  },
  error => {
    if (error.response) {
      switch (error.response.status) {
        case 401:
          userAuthentication().clearUser()
          router.replace({
            path: '/',
            query: { redirect: router.currentRoute.fullPath }
          })
          break
        case 403:
          // 403 无权限，跳转到首页
          router.replace({
            path: '/',
            query: { redirect: router.currentRoute.fullPath }
          })
          break
        case 500:
          console.error('axios-filter:' + error)
          break
      }
    }
    return Promise.reject(error)
  })
export default axios
