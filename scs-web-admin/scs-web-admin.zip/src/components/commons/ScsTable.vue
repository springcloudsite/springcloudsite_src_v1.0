<template>
  <div>
    <el-row v-if="buttons.length > 0">
      <el-col :span="24">
        <template v-for="button in buttons">
          <el-button :key="button.code" size="small" :type="button.type" @click="button.click">{{button.name}}</el-button>
        </template>
      </el-col>
    </el-row>
    <el-table ref="scsTable" :data="datas" @selection-change="handleSelectionChange" border>
      <template v-if="showSelection">
        <el-table-column :selectable="selectable" type="selection" width="50"></el-table-column>
      </template>
      <template v-if="showNum">
        <el-table-column type="index" width="50"></el-table-column>
      </template>
      <template v-for="column in columns">
        <el-table-column :key="column.prop" :prop="column.prop" :label="column.label" :width="column.width" :align="column.align">
          <template slot-scope="scope">
            <template v-if="column.renderCell">
              <render-column :column-scope="scope" :render-cell="column.renderCell"></render-column>
            </template>
            <template v-else>
              {{scope.row[column.prop]}}
            </template>
          </template>
        </el-table-column>
      </template>
    </el-table>
    <template v-if="isPager">
      <el-pagination :key="'page'" @current-change="handleCurrentChange" :current-page="pager.page" :page-size="pager.limit" layout="total, prev, pager, next" :total="pager.total">
      </el-pagination>
    </template>
  </div>
</template>

<script>
/*
tableOptions = {
  selectable: function (row, index) {}, // 仅对 type=selection 的列有效，类型为 Function，Function 的返回值用来决定这一行的 CheckBox 是否可以勾选
  showNum: false, // 是否显示序号列
  showSelection: false, // 是否显示复选框
  columns: [
    {
      prop: 'XXX', // 列属性
      label: 'XXX', // 列显示名称
      renderCell: function (h, scope) {
        // 列自定义显示方法
        let row = scope.row
        return h('el-switch', {
          attrs: {
            value: row.isDisable
          },
          props: {
            'active-value': '0',
            'inactive-value': '1'
          },
          on: {
            input: value => {
              row.isDisable = value
            }
          }
        })
      }
    }
  ],
  datas: [], // 显示数据
  dataUrl: url, // 远程连接数据地址
  isPager: true, // 是否分页显示
  pager: {
    limit: 10, // 每页显示多少数据
    page: 1, // 当前页
    sort: '', // 排序数据
    total: 0 // 总条数
  },
  buttons: [
    {
      code: '', // 按钮编码
      name: '', // 按钮显示名称
      click: function () {}, // 按钮点击事件(定义了click方法后，extendClick方法失效)
      type: '', // 按钮颜色类型
      extendClick: function () {} // 按钮扩展方法，在code为'add','edit','del'时，click事件可以使用默认事件，该方法提供具体业务逻辑
    }
  ],
  searchParams: {}, // 查询条件
  loadSuccess: function (response) {} // 远程数据加载完成后调用
}
*/
export default {
  name: 'scs-table',
  components: {
    'render-column': {
      render: function (createElement) {
        return this.renderCell(createElement, this.columnScope)
      },
      props: ['renderCell', 'columnScope']
    }
  },
  data () {
    let _opt = this.tableOption
    if (!_opt.pager) {
      _opt.pager = {}
    }
    let _buttons = _opt.buttons
    if (_buttons) {
      let _that = this
      let _button = null
      for (let i = 0, count = _buttons.length; i < count; i++) {
        _button = _buttons[i]
        switch (_button.code) {
          case 'add': {
            let ftnAdd = function (btn) {
              btn.name = btn.name || _that.$t('commons.buttons.add')
              btn.type = btn.type || 'primary'
              if (!$.isFunction(btn.click)) {
                btn.click = function () {}
              }
            }
            ftnAdd(_button)
            break
          }
          case 'edit': {
            let ftnEdit = function (btn) {
              btn.name = btn.name || _that.$t('commons.buttons.edit')
              btn.type = btn.type || 'primary'
              if ($.isFunction(btn.click)) {
                return
              }
              btn.click = function () {
                let _datas = []
                if (_opt.showSelection) {
                  _datas = _that.checkDatas
                }
                if (_datas.length !== 1) {
                  _that.$message({
                    message: '请选择一条数据进行编辑',
                    type: 'warning'
                  })
                  return
                }
                console.log(btn)
                if ($.isFunction(btn.extendClick)) {
                  btn.extendClick(_datas[0])
                }
              }
            }
            ftnEdit(_button)
            break
          }
          case 'del': {
            let ftnDel = function (btn) {
              btn.name = btn.name || _that.$t('commons.buttons.del')
              btn.type = btn.type || 'danger'
              if ($.isFunction(btn.click)) {
                return
              }
              btn.click = function () {
                let _datas = []
                if (_opt.showSelection) {
                  _datas = _that.checkDatas
                }
                if (_datas.length === 0) {
                  _that.$message({
                    message: '请选择要删除的数据',
                    type: 'warning'
                  })
                  return
                }
                if ($.isFunction(btn.extendClick)) {
                  btn.extendClick(_datas)
                }
              }
            }
            ftnDel(_button)
            break
          }
          default: {
            if (!$.isFunction(_button.click)) {
              _button.click = function () {}
            }
          }
        }
      }
    }
    let data = {
      selectable:
        _opt.selectable ||
        function (row, index) {
          return !row._disabled
        },
      showSelection: _opt.showSelection || false,
      showNum: _opt.showNum || false,
      datas: _opt.datas || [],
      columns: _opt.columns || [],
      checkDatas: [],
      isPager: _opt.isPager || false,
      pager: {
        limit: _opt.pager.limit || 10,
        page: _opt.pager.page || 1,
        sort: _opt.pager.sort,
        total: _opt.pager.total || 0
      },
      buttons: _buttons || []
    }
    return data
  },
  props: ['tableOption'],
  watch: {
    tableOption: {
      handler (curVal, oldVal) {
        this.columns = curVal.columns || []
        this.datas = curVal.datas || []
      },
      deep: true
    }
  },
  mounted () {
    // this.limit = 1
    this.initPageData()
  },
  methods: {
    initPageData () {
      if (this.tableOption.dataUrl) {
        let _params = this.tableOption.searchParams || {}
        if (this.isPager) {
          _params.page = this.pager.page
          _params.limit = this.pager.limit
          _params.sort = this.pager.sort
        }
        this.$axios({
          method: 'GET',
          url: this.tableOption.dataUrl,
          params: _params
        })
          .then(
            function (response) {
              let _data = response.data
              if (this.isPager) {
                this.pager.page = _data.page
                this.pager.total = _data.totalCount
                this.datas = _data.items
              } else {
                this.datas = response.data
              }
              let _loadSuccess = this.tableOption.loadSuccess
              if ($.isFunction(_loadSuccess)) {
                _loadSuccess(response)
              }
            }.bind(this)
          )
          .catch(function (error) {
            console.log(error)
          })
      }
    },
    getTable () {
      // 返回table实体对象
      return this.$refs.scsTable
    },
    getTableDatas () {
      // 返回列表数据
      return this.datas
    },
    getCheckDatas () {
      // 返回选中的值
      return this.checkDatas
    },
    handleSelectionChange (selection) {
      this.checkDatas = JSON.parse(JSON.stringify(selection))
      let fn = this.tableOption.selectionChange
      if ($.isFunction(fn)) {
        fn(selection)
      }
    },
    handleCurrentChange (curPage) {
      this.pager.page = curPage
      if (this.isPager) {
        this.initPageData()
      } else {
        this.$emit('currentChange', curPage)
      }
    }
  }
}
</script>
