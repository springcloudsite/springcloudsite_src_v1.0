<template>
  <div>
    <el-row>
      <el-col :span="11">
        <el-card shadow="never">
          <div slot="header" class="clearfix">
            <span>{{sourceTilte}}</span>
          </div>
          <scs-table ref="tableSource" :table-option="sourceOption"></scs-table>
        </el-card>
      </el-col>
      <el-col :span="2">
        <div class="middle-column">
          <el-button @click="removeData" :disabled="delButton" size="small" type="primary" icon="fa fa-chevron-left"></el-button>
          <el-button @click="addData" :disabled="addButton" size="small" type="primary" icon="fa fa-chevron-right"></el-button>
        </div>
      </el-col>
      <el-col :span="11">
        <el-card shadow="never">
          <div slot="header" class="clearfix">
            <span>{{targetTilte}}</span>
          </div>
          <scs-table ref="tableTarget" :table-option="targetOption"></scs-table>
        </el-card>
      </el-col>
    </el-row>
  </div>
</template>

<script>
import ScsTable from './ScsTable.vue'
/*
tranOption = {
  titles: {
    source: '', // 源标题
    targer: '' // 目标标题
  },
  columns: [], // 列属性
  source: { // 原配置
    dataUrl: '', // 远程连接数据地址
    datas: [], // 显示数据
    isPager: false, // 是否分页
    pager: {
      limit: 10, // 每页显示多少数据
      page: 1, // 当前页
      sort: '', // 排序数据
      total: 0 // 总条数
    }
  },
  target: { // 目标配置
    dataUrl: '', // 远程连接数据地址
    datas: [] // 显示数据
  }
}
*/
export default {
  name: 'transfer-table',
  components: { 'scs-table': ScsTable },
  props: ['tranOption'],
  data () {
    let _that = this
    let _tranOpt = this.tranOption
    _tranOpt.target = _tranOpt.target || {}
    let _targetDatas = []
    if (_tranOpt.target.datas) {
      _targetDatas = JSON.parse(JSON.stringify(_tranOpt.target.datas))
    }
    let data = {
      sourceTilte: _tranOpt.titles.source || '源标题',
      targetTilte: _tranOpt.titles.target || '目标标题',
      sourceOption: {
        showSelection: true,
        columns: _tranOpt.columns,
        datas: _tranOpt.source.datas,
        dataUrl: _tranOpt.source.dataUrl,
        isPager: _tranOpt.source.isPager,
        pager: _tranOpt.source.pager,
        selectionChange: function (selection) {
          _that.addButton = selection.length === 0
          _that.sourceSelectData = selection
        },
        loadSuccess: function (response) {
          // _that.filterData(response.data.items)
        }
      },
      targetOption: {
        showSelection: true,
        columns: _tranOpt.columns,
        datas: _targetDatas,
        dataUrl: _tranOpt.target.dataUrl,
        selectionChange: function (selection) {
          _that.delButton = selection.length === 0
          _that.targetSelectData = selection
        },
        selectable: function (row, index) {
          return true
        },
        loadSuccess: function (response) {
          // _that.filterData(response.data.items)
          if (!_that.target.datas) {
            _that.target.datas = response.data
          }
        }
      },
      sourceSelectData: [],
      targetSelectData: [],
      addButton: true,
      delButton: true
    }
    return data
  },
  watch: {},
  mounted () {
    this.initData()
  },
  methods: {
    initData: function () {
    },
    removeData: function () {
      let _datas = this.targetSelectData
      let _count = _datas.length
      let _tDatas = this.$refs.tableTarget.getTableDatas()
      for (let i = _tDatas.length; i > 0; i--) {
        for (let j = 0; j < _count; j++) {
          if (_datas[j].id === _tDatas[i - 1].id) {
            _tDatas.splice(i - 1, 1)
            break
          }
        }
      }

      this.filterData(_datas, false)
      this.targetSelectData = []
      this.delButton = true
    },
    addData: function () {
      // 添加选中数据
      let _datas = this.sourceSelectData
      this.filterData(_datas)
      let _tDatas = this.$refs.tableTarget.getTableDatas()
      this.targetOption.datas = _tDatas.concat(_datas)
      this.sourceSelectData = []
      this.addButton = true
      this.$refs.tableSource.getTable().clearSelection()
    },
    filterData: function (selectData, isDisabled) {
      //
      if (isDisabled !== false) {
        isDisabled = true
      }
      let source = this.$refs.tableSource.getTableDatas()
      for (let i = 0, count = source.length; i < count; i++) {
        if (source[i]._disabled === undefined) {
          this.$set(source[i], '_disabled', false)
        }
        for (let j = 0, c = selectData.length; j < c; j++) {
          if (selectData[j].id === source[i].id) {
            source[i]._disabled = isDisabled
            break
          }
        }
      }
    },
    getDelDatas: function () {
      // 获取删除的数据
      let delData = []
      let _target = this.tranOption.target.datas
      let _cur = this.$refs.tableTarget.getTableDatas()
      let count = _cur.length
      _target.filter((v, i, r) => {
        let isDel = true
        for (let i = 0; i < count; i++) {
          if (v.id === _cur[i].id) {
            isDel = false
            break
          }
        }
        if (isDel) {
          delData.push(v)
        }
      })
      return delData
    },
    getAddDatas: function () {
      // 获取添加的数据
      let addData = []
      let _target = this.tranOption.target.datas
      let _cur = this.$refs.tableTarget.getTableDatas()
      let count = _target.length
      _cur.filter((v, i, r) => {
        let isAdd = true
        for (let i = 0; i < count; i++) {
          if (v.id === _target[i].id) {
            isAdd = false
            break
          }
        }
        if (isAdd) {
          addData.push(v)
        }
      })
      return addData
    }
  }
}
</script>

<style>
.el-card__body {
  padding: 0;
}
</style>