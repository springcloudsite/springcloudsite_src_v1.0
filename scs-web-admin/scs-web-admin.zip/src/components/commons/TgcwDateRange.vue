<template>
  <Row>
    <Col span="11">
    <FormItem :prop="startDateProp">
      <DatePicker v-model="startDate" @on-change="dateStart" :options="optDateStart" :placeholder="startPlaceholder" :transfer="transfer" :editable="false" :readonly="isDisabled" :disabled="isDisabled" type="date" format="yyyy-MM-dd"></DatePicker>
    </FormItem>
    </Col>
    <Col span="2" style="text-align: center">-</Col>
    <Col span="11">
    <template v-if="!isPermanent">
      <FormItem :prop="endDateProp">
        <DatePicker v-model="endDate" @on-change="dateEnd" :options="optDateEnd" :placeholder="endPlaceholder" :transfer="transfer" :editable="false" :readonly="isDisabled" :disabled="isDisabled" type="date" format="yyyy-MM-dd"></DatePicker>
      </FormItem>
    </template>
    <template v-if="isPermanent">
      <FormItem prop="tgcw-forever">
        <DatePicker :open="open" v-model="endDate" :options="optDateEnd" @on-change="dateEnd" :transfer="transfer" :editable="false" :readonly="isDisabled" :disabled="isDisabled" type="date" format="yyyy-MM-dd">
          <a href="javascript:void(0)" @click="handleClick" :disabled="isDisabled">
            永久
          </a>
        </DatePicker>
      </FormItem>
    </template>
    </Col>
  </Row>
</template>

<script>
export default {
  name: 'tgcw-date-range',
  data () {
    let that = this
    let data = {
      transfer: this.dateOption.transfer || false,
      startDate: '', // 开始时间
      startPlaceholder: '', // 开始时间提示信息
      startDateProp: this.dateOption.startDateProp, // 开始时间校验属性名称
      endDate: '', //  结束时间
      endPlaceholder: '', // 结束时间提示信息
      endDateProp: this.dateOption.endDateProp, // 结束时间校验属性名称
      parentObj: '', // 父组件对象
      formName: '', // 表单名称
      open: false, // 手动打开时间控件标志
      isPermanent: false, // 是否是长期时间标志
      isDisabled: false, // 禁用标志
      optDateStart: {
        //  开始时间规则
        disabledDate: function (date) {
          if (typeof date === 'string') {
            date = that.stringToDate(date)
          }
          // let compDate = new Date()
          let compDate = that.endDate
          let result = false
          if (!compDate) {
            return result
          }
          if (compDate instanceof Date) {
            result = date.getTime() >= compDate.getTime()
          } else if (typeof compDate === 'string') {
            compDate = that.stringToDate(compDate)
            if (compDate instanceof Date) {
              result = date.getTime() >= compDate.getTime()
            }
          }
          return result
        }
      },
      optDateEnd: {
        //  结束时间规则
        shortcuts: [
          {
            text: '10年',
            value () {
              let start = that.startDate
              let date = that.stringToDate(start)
              date.setFullYear(date.getFullYear() + 10)
              if (date.getTime() < new Date().getTime()) {
                that.$Message.error('结束时间不能早于当前时间')
                date = null
              }
              return date
            },
            onClick: picker => {}
          },
          {
            text: '20年',
            value () {
              let start = that.startDate
              let date = that.stringToDate(start)
              date.setFullYear(date.getFullYear() + 20)
              if (date.getTime() < new Date().getTime()) {
                that.$Message.error('结束时间不能早于当前时间')
                date = null
              }
              return date
            },
            onClick: picker => {}
          },
          {
            text: '长期',
            value () {
              if (that.parentObj) {
                let valis = {}
                valis[that.endDateProp] = true
                that.clearValidateMsg(
                  that.parentObj.$refs[that.formName],
                  valis
                )
              }
              that.isPermanent = true
              return null
            },
            onClick: picker => {}
          }
        ],
        disabledDate: function (date) {
          if (typeof date === 'string') {
            date = that.stringToDate(date)
          }
          // let compDate = new Date()
          let compDate = that.startDate
          let result = false
          if (!compDate) {
            return result
          }
          if (compDate instanceof Date) {
            result = date.getTime() <= compDate.getTime()
          } else if (typeof compDate === 'string') {
            compDate = that.stringToDate(compDate)
            if (compDate instanceof Date) {
              result = date.getTime() <= compDate.getTime()
            }
          }
          return result
        }
      }
    }
    return data
  },
  props: ['dateOption', 'parentDisabled'],
  watch: {
    'dateOption.startDate': function (newValue, oldValue) {
      this.startDate = newValue
    },
    'dateOption.endDate': function (newValue, oldValue) {
      this.endDate = newValue
    },
    'dateOption.isPermanent': function (newValue, oldValue) {
      this.isPermanent = newValue
    },
    parentDisabled: function (newValue, oldValue) {
      this.isDisabled = newValue
    }
  },
  mounted () {
    this.initData()
  },
  methods: {
    initData: function () {
      this.startDate = this.dateOption.startDate
      this.startPlaceholder = this.dateOption.startPlaceholder
      this.endDate = this.dateOption.endDate
      this.endPlaceholder = this.dateOption.endPlaceholder
      this.parentObj = this.dateOption.parentObj
      this.formName = this.dateOption.formName
      this.isPermanent = this.dateOption.isPermanent || false
      this.isDisabled = this.parentDisabled
      if (this.isDisabled !== true) {
        this.isDisabled = false
      }
    },
    handleClick: function () {
      this.open = !this.open
    },
    dateStart: function (event) {
      this.startDate = event
      this.$emit('start-date', event)
    },
    dateEnd: function (event) {
      this.$emit('end-date', event)
      if (event) {
        this.isPermanent = false
      } else {
        this.open = false
        if (this.parentObj) {
          let valis = {
            'tgcw-forever': true
          }
          this.clearValidateMsg(
            this.parentObj.$refs[this.formName],
            valis
          )
        }
      }
      this.$emit('is-permanent', this.isPermanent)
      this.endDate = event
    },
    stringToDate: function (cur) {
      let date = new Date()
      if (typeof cur === 'string') {
        if (cur) {
          date = new Date(Date.parse(cur.replace(/-/g, '/')))
        }
      } else if (cur.constructor === Date) {
        date = new Date(cur.valueOf())
      }
      return date
    }
  }
}
</script>
