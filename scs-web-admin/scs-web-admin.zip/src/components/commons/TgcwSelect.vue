<template> 
     <Select v-model="value"   @on-change="select">
        <Option v-for="item in dictList" :value="item.code" :key="item.code">{{ item.label }}</Option>
    </Select>
</template>
<script>
    export default {
      data () {
        return {
          url: this.global.serverSys + this.global.url.sysdictionary + '/',
          value: '',
          dictList: []
        }
      },
      props: ['datatype', 'default'],
  mounted () {
        this.$axios({
          method: 'get',
          url: this.url + this.datatype
        }).then(function (response) {
          this.dictList = response.data
        }.bind(this)).catch(function (error) {
          console.log(error)
        })
        if (this.default) {
          this.value = this.default
        }
  },
      methods: {
        select: function () {
          this.$emit('ref', this.value)
        }
      }
    }

</script>