<template>
    <transition name="el-zoom-in-top">
      <div class="content-wrapper">
wefwefwefwefwefwefwefwef
        <!-- Main content -->
        <section class="content">
          <div class="box">
            <div class="box-header with-border">
              <h3 class="box-title">分页</h3>
              <div class="box-tools pull-right">
                <button type="button" data-widget="collapse" data-toggle="tooltip" title="Collapse" class="btn btn-box-tool"><i class="ti-minus"></i></button>
                <button type="button" data-widget="remove" data-toggle="tooltip" title="Remove" class="btn btn-box-tool"><i class="ti-close"></i></button>
              </div>
            </div>
            <div class="box-body" style="min-height:400px;">
              <h3 class="box-title">基本的分页，页数过多时会自动折叠。</h3>
              <Page :total="100"></Page>
              <br>
              <h3 class="box-title">电梯分页，快速跳转到某一页。。</h3>
              <Page :total="100" show-elevator></Page>
            </div>
          </div>
        </section>
        <!-- /.content -->
      </div>
    </transition>
</template>
<script>
export default {
  name: 'form'
}
</script>
