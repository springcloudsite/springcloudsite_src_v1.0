<template>
    <transition name="el-zoom-in-top">
        <div class="content-wrapper">
       <!-- Content Header (Page header) -->
        <section class="content-header">
            <h1>Simple Table<small>It's all start from here <i class="ti-heart"></i><i class="ti-export"></i><i class="ti-printer"></i></small></h1>
            <ol class="breadcrumb">
                <li><router-link to="/"> <i class="ti-home"></i></router-link></li>
                <li><a href="#">Table</a></li>
                <li class="active">    </li>
            </ol>
        </section>
  
            <!-- Main content -->
            <section class="content">
               <!-- Basic Tables-->
                <div class="box">
                     <el-button type="success" @click="DemoTestClick()">测试数据加载</el-button>
                    <div class="box-header with-border">
                        <h3 class="box-title">Basic Tables</h3>
                        <div class="box-tools pull-right">
                            <button type="button" data-widget="collapse" data-toggle="tooltip" title="Collapse" class="btn btn-box-tool"><i class="ti-minus"></i></button>
                            <button type="button" data-widget="remove" data-toggle="tooltip" title="Remove" class="btn btn-box-tool"><i class="ti-close"></i></button>
                        </div>
                    </div>
                    <div class="box-body">
                          <el-table
                          :data="tableData"
                          style="width: 100%">
                          <el-table-column
                            prop="date"
                            label="Date"
                            width="180">
                          </el-table-column>
                          <el-table-column
                            prop="name"
                            label="Name"
                            width="180">
                          </el-table-column>
                          <el-table-column
                            prop="address"
                            label="Address">
                          </el-table-column>
                        </el-table>
                    </div>
                </div>
                <!-- End of Basic Tables-->
                <!-- Striped Table-->
                <div class="box">
                    <div class="box-header with-border">
                        <h3 class="box-title">Striped Table</h3>
                        <div class="box-tools pull-right">
                            <button type="button" data-widget="collapse" data-toggle="tooltip" title="Collapse" class="btn btn-box-tool"><i class="ti-minus"></i></button>
                            <button type="button" data-widget="remove" data-toggle="tooltip" title="Remove" class="btn btn-box-tool"><i class="ti-close"></i></button>
                        </div>
                    </div>
                    <div class="box-body">
                              <el-table
                            :data="tableData"
                            stripe
                            style="width: 100%">
                            <el-table-column
                              prop="date"
                              label="Date"
                              width="180">
                            </el-table-column>
                            <el-table-column
                              prop="name"
                              label="Name"
                              width="180">
                            </el-table-column>
                            <el-table-column
                              prop="address"
                              label="Address">
                            </el-table-column>
                          </el-table>
                    </div>
                </div>
                <!-- End of Striped Table-->
                <!-- Striped Table-->
                <div class="box">
                    <div class="box-header with-border">
                        <h3 class="box-title">Table with fixed header</h3>
                        <div class="box-tools pull-right">
                            <button type="button" data-widget="collapse" data-toggle="tooltip" title="Collapse" class="btn btn-box-tool"><i class="ti-minus"></i></button>
                            <button type="button" data-widget="remove" data-toggle="tooltip" title="Remove" class="btn btn-box-tool"><i class="ti-close"></i></button>
                        </div>
                    </div>
                    <div class="box-body">
                          <el-table
                            :data="tableData"
                            height="250"
                            border
                            style="width: 100%">
                            <el-table-column
                              prop="date"
                              label="Date"
                              width="180">
                            </el-table-column>
                            <el-table-column
                              prop="name"
                              label="Name"
                              width="180">
                            </el-table-column>
                            <el-table-column
                              prop="address"
                              label="Address">
                            </el-table-column>
                          </el-table>
                    </div>
                </div>
            <div class="box">
                 <Page :total="total" :page-size="pageInfo.pageSize" show-elevator show-total @on-change="e=>{pageSearch(e)}"></Page>
           </div>
                <!-- End of Striped Table-->
                
                
            </section>
            <!-- /.content -->
                 <Spin size="large" fix v-if="spinShow"></Spin>
        </div>
    </transition>
</template>
<script>
    export default {
      name: 'SimpleTable',
      data: function () {
        return {
          spinShow: false,
          pageInfo: {
            page: 1,
            pageSize: 5
          },
          total: 1000,
          loginName: 'zhangsan',
          messagevalue: '',
          tableData: [],
          geturl: 'http://10.11.60.1:8769/tgcw-service-fyz/fyzprojects/pager'
        }
      },
      mounted () {
        this.getTable({
          'pageInfo': this.pageInfo,
          'loginName': this.loginName
        })
      },
      methods: {
        getTable (e) {
          console.log('gettable test')
          console.log('pageSize' + e.pageInfo.pageSize)
          console.log('loginName' + e.loginName)
          let that = this
          that.spinShow = true
          this.$axios({
            method: 'get',
            url: this.geturl,
            params: {
              'page': e.pageInfo.page,
              'limit': e.pageInfo.pageSize,
              'sort': 'id.desc,name.asc'
            }
          }).then(function (response) {
            var recivedata = response.data
            this.tableData = recivedata.items
            this.total = recivedata.totalCount
            that.spinShow = false
            //  this.total=response.data.totalCount;
          }.bind(this)).catch(function (error) {
            that.spinShow = false
            console.log(error)
          })
        },
        pageSearch: function (e) {
          this.pageInfo.page = e - 1
          console.log(e)
          this.getTable({
            'pageInfo': this.pageInfo,
            'loginName': this.loginName
          })
        },
        DemoTestClick: function () {
          this.$axios({
            method: 'get',
            url: this.geturl,
            params: {
              'test': '123456'
            }
          }).then(function (response) {
            this.tableData = response.data
          }.bind(this)).catch(function (error) {
            console.log(error)
          })
        }
  }
    }
</script>
