<template>
  <el-row>
    <el-col :span="24" class="main">
      <!--导航菜单-->

      <section class="content-container">
        <div class="header-img">
          <img src="static/img/index-banner.png" width="100%" height="auto" />
          <menu-sidebar :menu-tree="menuTree" :cur-menu="curMenu"></menu-sidebar>

          <!-- <div class="header-tabs">
            <div class="menu-tabs">
              <a href="javascript:void()" @mouseover="tabsMenu('aa', 'show')" @mouseout="tabsMenu('aa', 'hide');">平台介绍</a>
              <a href="javascript:void()" @mouseover="tabsMenu('bb', 'show');" @mouseout="tabsMenu('bb', 'hide');">源码下载</a>
              <a href="javascript:void()" @mouseover="tabsMenu('cc', 'show');" @mouseout="tabsMenu('cc', 'hide');">在线文档</a>
              <a href="javascript:void()" @mouseover="tabsMenu('dd', 'show');" @mouseout="tabsMenu('dd', 'hide');">在线演示</a>
            </div>
            <div class="box-bg" id="aa" @mouseover="tabsMenu('aa', 'show');" @mouseout="tabsMenu('aa', 'hide');">
              <table class="tabs-name" width="100%" border="0" cellspacing="0" cellpadding="0">
                <tr>
                  <td>智能分析</td>
                  <td>对标分析</td>
                  <td>线性分析</td>
                  <td>分析数据</td>
                </tr>
                <tr>
                  <td>机器学习</td>
                  <td>方案管理</td>
                  <td>分析对象类型管理</td>
                  <td>分析对象管理</td>
                </tr>
                <tr>
                  <td>指标类型管理</td>
                  <td>指标管理</td>
                  <td>算法实验室</td>
                  <td>&nbsp;</td>
                </tr>
              </table>
            </div>
            <div class="box-bg" id="bb" @mouseover="tabsMenu('bb', 'show');" @mouseout="tabsMenu('bb', 'hide');">
              <a href="#">bb </a>
              <a href="#">bb </a>
              <a href="#">bb </a>
              <a href="#">bb </a>
            </div>
            <div class="box-bg" id="cc" @mouseover="tabsMenu('cc', 'show');" @mouseout="tabsMenu('cc', 'hide');">
              <a href="#">33 </a>
              <a href="#">33 </a>
              <a href="#">33 </a>
              <a href="#">33 </a>
            </div>
          </div> -->

          <div class="header-text">
            <h1>新一代智能数据工厂，让数据更智能！</h1>
            <p><strong>数据研发，易如反掌</strong></p>
            <el-button type="opacity">点击查看</el-button>
          </div>
        </div>
        <div class="content">
          <h2>全球领先、安全、稳定的云计算产品</h2>
          <div class="mb20">
            <el-row :gutter="20">
              <el-col :span="8">
                <h3>快速的响应架构</h3>
                <p>SpringCloudSite 采用了目前极为流行的扁平化响应式的设计风格。前端UI基于 Vue Elementui实现，后台基于最主流的 Spring Cloud + MyBatis +  Redis  的稳定架构。</p>
              </el-col>
              <el-col :span="4">
                <div class="icon-bg01">
                  <img src="static/img/icon01.png" /><br>
                  <strong>开发架构</strong>
                </div>
              </el-col>
              <el-col :span="4">
                <div class="icon-bg02">
                  <img src="static/img/icon02.png" /><br>
                  <strong>基础平台</strong>
                </div>
              </el-col>
              <el-col :span="8">
                <h3>基础平台</h3>
                <p>代码生成工具，此工具提供常用的单表、一对多、树结构及列表查询等功能的生成，如果对外观要求不是很高，生成的功能就可以用了。如果你使用了本平台，就可以很简单很高效的快速开发出优秀的产品。</p>
              </el-col>
            </el-row>
          </div>
          <div>
            <el-row :gutter="20">
              <el-col :span="8">
                <h3>行业专业</h3>
                <p>自开源以来被用到了电信、金融、能源、互联网等各个领域中，设计思想和开发模式也深入支持者的内心， 当团队结合了以往的经验和总结各方面的应用案例，总结了一个比较全面应用的微服务架构，也纳入很多新的思想。</p>
              </el-col>
              <el-col :span="4">
                <div class="icon-bg03">
                  <img src="static/img/icon03.png" /><br>
                  <strong>行业扩展</strong>
                </div>
              </el-col>
              <el-col :span="4">
                <div class="icon-bg04">
                  <img src="static/img/icon04.png" /><br>
                  <strong>安全稳定</strong>
                </div>
              </el-col>
              <el-col :span="8">
                <h3>安全稳定</h3>
                <p>SpringCloudSite 严格遵循了Web安全的规范，前后台双重验证，参数编码传输，密码策略，密码散列加密存储，精细的权限验证，SQL编码过滤，从根本上避免了SQL注入，XSS攻击，CSRF攻击等常见的web攻击手段。</p>
              </el-col>
            </el-row>
          </div>
        </div><br><br>
        <div class="index-Mbg">
          <div class="content">
            <el-row :gutter="20">
            <el-col :span="6">
              <div class="round">
                <img src="static/img/Micon01.png" width="60%" height="auto" />
              </div>
              基础数据录入
            </el-col>
            <el-col :span="6">
              <div class="round">
                <img src="static/img/Micon02.png" width="60%" height="auto" />
              </div>
              实时数据接口、数据上传
            </el-col>
            <el-col :span="6">
              <div class="round">
                <img src="static/img/Micon03.png" width="60%" height="auto" />
              </div>
              系统在线分析、决策
            </el-col>
            <el-col :span="6">
              <div class="round">
                <img src="static/img/Micon04.png" width="60%" height="auto" />
              </div>
              人工专家服务
            </el-col>
          </el-row>
          </div>
        </div>
        <div class="content">
          <h2>为什么选择SpringCloudSite </h2>
          <table class="timeline" border="0" cellspacing="0" cellpadding="0">
            <tr>
              <td width="253">
                <img src="static/img/timeline01.png" />
              </td>
              <td width="253">
                <img src="static/img/timeline01.png" />
              </td>
              <td width="253">
                <img src="static/img/timeline01.png" />
              </td>
              <td>
                <img src="static/img/timeline02.png" />
              </td>
            </tr>
            <tr>
              <td>
                <h4>简单、高效</h4>
              </td>
              <td>
                <h4>架构、优良</h4>
              </td>
              <td>
                <h4>微服务、集群</h4>
              </td>
              <td>
                <h4>AI应用时代<br>专业级AI</h4>
              </td>
            </tr>
            <tr>
              <td>
                <p>经典架构会的人多，节省培训人力成本，缩短项目周期，快速交付</p>
              </td>
              <td>
                <p>安全稳定，方便第三方扩展，模块插拔方便，性能优良</p>
              </td>
              <td>
                <p>Spring Cloud，Redis会话共享，松耦合设计，方便升级</p>
              </td>
              <td>
                <p>针对专业行业及专业领域，由人工智能代替人工的过程，靠体力或低端脑力劳动者逐渐被机器代替</p>
              </td>
            </tr>
          </table>
        </div>
      </section>
    </el-col>
  </el-row>
</template>

<script>
import MenuSidebar from '../partials/MenuSidebar.vue'
export default {
  name: 'home',
  props: ['menuTree', 'curMenu'],
  components: { 'menu-sidebar': MenuSidebar },
  methods: {
    // tabs导航栏
    tabsMenu: function (obj, sType) {
      var oDiv = document.getElementById(obj)
      if (sType === 'show') { oDiv.style.display = 'block' }
      if (sType === 'hide') { oDiv.style.display = 'none' }
    }
  }
}
</script>

<style scoped lang="scss">
.header-img{
  position: relative;
}
.header-text{
  position: absolute;
  bottom: 80px;
  left: 30px;
  color: #fff;
}
.header-text h1{
  font-size: 36px;
}
.icon-bg01{
  background-color: #3da3d8;
  text-align: center;
  color: #fff;
  height: 120px;
  padding-top: 15px;
  line-height: 1.8em;
}
.icon-bg02{
  background-color: #b6b6b6;
  text-align: center;
  color: #fff;
  height: 115px;
  padding-top: 20px;
  line-height: 1.8em;
}
.icon-bg03{
  background-color: #256485;
  text-align: center;
  color: #fff;
  height: 115px;
  padding-top: 20px;
  line-height: 1.8em;
}
.icon-bg04{
  background-color: #ffd200;
  text-align: center;
  color: #fff;
  height: 115px;
  padding-top: 20px;
  line-height: 1.8em;
}
.index-Mbg{
  background: url("../../../static/img/index-Mbg.png") no-repeat;
  padding: 20px 0;
  color: #fff;
  text-align: center;
}
.index-Mbg .round{
  border-radius: 50px;
  width: 100px;
  height: 100px;
  line-height: 150px;
  margin: 10px auto;
  border: #fff 2px solid;
}
.timeline{
  margin: 0 auto;
  width: 1022px;
}
.timeline td{
  text-align: center;
}
.timeline td p{
  padding: 10px 40px;
}
// 暂时使用
.main-menu {
  position: absolute;
  top: -60px;
  width: 100%;
}
</style>
