<style>
.navmenu {
  padding: 10px 0;
}
</style>
<template>
  <transition name="el-zoom-in-center">
    <div class="content-wrapper">
      <!-- Main content -->
      <section class="">
        <div class="box">
          <div class="box-body">
            <el-row :gutter="20">
              <el-col :span="12">
                <scs-table ref="tableUser11" :table-option="tableOption11"></scs-table>
              </el-col>
              <el-col :span="12">
                <el-button type="primary" @click="1">执行分析</el-button>
                <el-button type="primary" @click="1">保存参数</el-button>
                <el-form class="mtb20" ref="form" :model="form" label-width="80px">
                  <el-input type="textarea" :rows="10" v-model="form.desc"></el-input>
                </el-form>
                <el-button type="primary" @click="openDialog">添加关系函数</el-button>
                <el-button type="primary" @click="1">删除关系函数</el-button>
                <scs-table class="mt20" ref="tableUser" :table-option="tableOption"></scs-table>
                <el-dialog title="添加关系函数" :visible.sync="indexSelector.open">
                  <el-form ref="form" :model="form" label-width="80px">
                    <el-form-item label="关系函数">
                      <el-input type="textarea" v-model="form.desc"></el-input>
                    </el-form-item>
                  </el-form>
                  <div class="dialog-footer" slot="footer">
                    <el-button type="primary" @click="handleTypeSelector">保存</el-button>
                  </div>
                </el-dialog>
              </el-col>
            </el-row>
          </div>
          <!-- /.box-body -->
          <div class="box-body">
            <h2 class="h-01">数据详情</h2>
            <el-row :gutter="20">
              <el-col :span="24">
                <scs-table ref="tableUser22" :table-option="tableOption22"></scs-table>
              </el-col>
            </el-row>
          </div>
          <!-- /.box-body -->
        </div>
        <!-- /.box -->

      </section>
      <!-- /.content -->
      <Spin size="large" fix v-if="spinShow"></Spin>
    </div>

  </transition>

</template>
<script>
import ScsTable from '../../commons/ScsTable.vue'
export default {
  components: {
    'scs-table': ScsTable
  },
  data () {
    return {
      form: {
        name: '',
        region: '',
        date1: '',
        date2: '',
        delivery: false,
        type: [],
        resource: '',
        desc: ''
      },
      tableOption: {
        // showNum: true,
        showSelection: true,
        columns: [
          {
            prop: 'name',
            label: '字段名'
          },
          {
            prop: 'function',
            label: '函数'
          }
        ],
        datas: [
          {
            id: 1,
            name: '开度',
            function: '惰性乘以0.5'
          },
          {
            id: 2,
            name: '二次网',
            function: '一次网乘以0.5'
          },
          {
            id: 3,
            name: '耗电',
            function: '乘以0.5'
          }
        ],
        // dataUrl:
        //     this.global.serverPathUser +
        //     this.global.url.user.getPagerUndeletedUsersBySearch,
        // isPager: true,
        pager: {
          sort: 'id.asc'
        },
        searchParams: {}
      },
      tableOption11: {
        // showNum: true,
        // showSelection: true,
        columns: [
          {
            prop: 'type1',
            label: '外温'
          },
          {
            prop: 'type2',
            label: '一网温度'
          },
          {
            prop: 'type3',
            label: '惰性'
          }
        ],
        datas: [
          {
            type1: '25',
            type2: '24',
            type3: '25'
          },
          {
            type1: '25',
            type2: '23',
            type3: '25'
          },
          {
            type1: '232',
            type2: '234',
            type3: '232'
          },
          {
            type1: '153',
            type2: '121',
            type3: '153'
          },
          {
            type1: '-43',
            type2: '-22',
            type3: '-43'
          },
          {
            type1: '11',
            type2: '12',
            type3: '11'
          },
          {
            type1: '25',
            type2: '24',
            type3: '25'
          },
          {
            type1: '25',
            type2: '24',
            type3: '25'
          },
          {
            type1: '25',
            type2: '24',
            type3: '25'
          },
          {
            type1: '25',
            type2: '24',
            type3: '25'
          },
          {
            type1: '25',
            type2: '24',
            type3: '25'
          }
        ],
        // dataUrl:
        //     this.global.serverPathUser +
        //     this.global.url.user.getPagerUndeletedUsersBySearch,
        // isPager: true,
        pager: {
          sort: 'id.asc'
        },
        searchParams: {}
      },
      tableOption22: {
        // showNum: true,
        // showSelection: true,
        columns: [
          {
            prop: 'type1',
            label: '室内温度'
          },
          {
            prop: 'type2',
            label: '耗电'
          },
          {
            prop: 'type3',
            label: '耗热'
          },
          {
            prop: 'type4',
            label: '二次温度'
          },
          {
            prop: 'type5',
            label: '开度'
          }
        ],
        datas: [
          {
            type1: '25',
            type2: '24',
            type3: '25',
            type4: '25',
            type5: '25'
          },
          {
            type1: '25',
            type2: '23',
            type3: '25',
            type4: '25',
            type5: '25'
          },
          {
            type1: '232',
            type2: '234',
            type3: '232',
            type4: '232',
            type5: '232'
          },
          {
            type1: '153',
            type2: '121',
            type3: '153',
            type4: '153',
            type5: '153'
          },
          {
            type1: '-43',
            type2: '-22',
            type3: '-43',
            type4: '-43',
            type5: '-43'
          },
          {
            type1: '11',
            type2: '12',
            type3: '11',
            type4: '11',
            type5: '11'
          },
          {
            type1: '25',
            type2: '24',
            type3: '25',
            type4: '25',
            type5: '25'
          },
          {
            type1: '25',
            type2: '24',
            type3: '25',
            type4: '25',
            type5: '25'
          },
          {
            type1: '25',
            type2: '24',
            type3: '25',
            type4: '25',
            type5: '25'
          },
          {
            type1: '25',
            type2: '24',
            type3: '25',
            type4: '25',
            type5: '25'
          },
          {
            type1: '25',
            type2: '24',
            type3: '25',
            type4: '25',
            type5: '25'
          }
        ],
        // dataUrl:
        //     this.global.serverPathUser +
        //     this.global.url.user.getPagerUndeletedUsersBySearch,
        // isPager: true,
        pager: {
          sort: 'id.asc'
        },
        searchParams: {}
      },
      indexSelector: {
        open: false,
        indexCheck: '',
        indexType: ''
      }
    }
  },
  methods: {
    openDialog () {
      this.indexSelector = {
        open: true
      }
    }
  }
}
</script>
