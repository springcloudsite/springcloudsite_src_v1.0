<style>
</style>
<template>

  <transition name="el-zoom-in-center">

    <div class="content-wrapper">
      <!-- <section class="content-header">
        <ol class="breadcrumb">
          <li>
            <router-link to="/">
              <i class="ti-home"></i>
            </router-link>
          </li>
          <li>
            <a href="#">Forms </a>
          </li>
          <li class="active">Input</li>
        </ol>
      </section> -->

      <!-- Main content -->
      <section>
        <!-- Default box -->
        <div class="box">
          <div class="box-body">
            <el-row :gutter="20">
              <el-button type="primary" @click="1">CSV文件导入</el-button>
              <el-button type="primary" @click="1">智能分析导入</el-button>
              <el-button type="primary" @click="1">对标分析导入</el-button>
              <el-button type="primary" @click="1">线性分析导入</el-button>
              <el-col :span="24">
                <el-table :data="tableData">
                  <el-table-column prop="id" label="序号" width="180"></el-table-column>
                  <el-table-column prop="name" label="数据名称" width="180"></el-table-column>
                  <el-table-column prop="type" label="类型"></el-table-column>
                  <el-table-column prop="authority" label="权限"></el-table-column>
                  <el-table-column prop="operate" label="操作">
                    <template slot-scope="scope">
                        <el-button type="text" @click="dialogFormVisible = true">查看</el-button>
                        <el-button type="text" size="small">删除</el-button>
                    </template>
                  </el-table-column>
                </el-table>
              </el-col>
            </el-row>
          </div>
          <!-- /.box-body -->
        </div>
        <!-- /.box -->

      </section>
      <!-- /.content -->
      <Spin size="large" fix v-if="spinShow"></Spin>
    </div>

  </transition>

</template>
<script>
export default {
  data () {
    return {
      tableData: [{
        id: '#1',
        name: '面积',
        type: '智能分析',
        authority: 'admin'
      }, {
        id: '#2',
        name: '热单耗',
        type: '对标分析',
        authority: 'admin'
      }, {
        id: '#3',
        name: '水单耗',
        type: '线性分析',
        authority: 'admin'
      }, {
        id: '#4',
        name: '收费总额',
        type: '导入数据',
        authority: 'admin'
      }]
    }
  }
}
</script>
