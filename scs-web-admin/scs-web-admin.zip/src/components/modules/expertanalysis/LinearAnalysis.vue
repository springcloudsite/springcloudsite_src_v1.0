<style>
.navmenu{
  padding: 10px 0;
}
</style>
<template>
  <transition name="el-zoom-in-center">
    <div class="content-wrapper">
      <!-- <section class="content-header">
        <ol class="breadcrumb">
          <li>
            <router-link to="/">
              <i class="ti-home"></i>
            </router-link>
          </li>
          <li>
            <a href="#">Forms </a>
          </li>
          <li class="active">Input</li>
        </ol>
      </section> -->

      <!-- Main content -->
      <section class="">
        <!-- Default box -->
        <div class="box">
          <div class="box-body" style="margin-top:10px;">
            <el-row>
              <el-col :span="5">
              对象类型：
              <el-select v-model="rlz" style="width:100px;" size="small">
                <el-option v-for="item in rlzs" :key="item.value" :label="item.label" :value="item.value"></el-option>
              </el-select>
              </el-col>
              <el-col :span="6" style="width: 22%;">
              开始时间：
              <el-date-picker style="width:130px;" size="small" v-model="startDate" type="date" placeholder="选择日期"></el-date-picker>
              </el-col>
              <el-col :span="6" style="width: 22%;">
              结束时间：
              <el-date-picker style="width:130px;" size="small" v-model="endDate" type="date" placeholder="选择日期"></el-date-picker>
              </el-col>
              <el-col :span="2">
              <el-checkbox v-model="checked" style="width: 100px;margin-top: 7px;" size="small">当前时间</el-checkbox>
              </el-col>
              <el-col :span="4">
              周期：
              <el-select v-model="zq" style="width:100px;" size="small">
                <el-option v-for="item in zqs" :key="item.value" :label="item.label" :value="item.value"></el-option>
              </el-select>
              </el-col>
              <el-col :span="1">
                <el-button type="success" @click="newOk('userNew')" size="small">线性分析</el-button>
              </el-col>
            </el-row>
            <el-row >
              <el-col :span="4" class="navmenu">
                <div style="margin-top: 10px;">
                  <el-tree :data="data" :props="defaultProps" :highlight-current="highlightCurrent" :default-expand-all="defaultExpandAll" @check-change="handleNodeClick" check-on-click-node show-checkbox></el-tree>
                </div>
                <div v-for="task in taskList" :key="task.id">
                  <a :data-id="task.id" href="javascript:void(0)" @click="showTaskDetails($event)">{{task.name}}</a>
                </div>
              </el-col>
              <el-col :span="20">
                <div style="margin-top: 10px;">
                  <el-table class="mb20" :data="tableData" style="width: 100%">
                    <el-table-column prop="id" label="ID" width="180" align="center"></el-table-column>
                    <el-table-column prop="bs" label="唯一标识" width="180" align="center"></el-table-column>
                    <el-table-column prop="dx" label="对象名称" align="center"></el-table-column>
                    <el-table-column prop="lx" label="类型名称" align="center"></el-table-column>
                  </el-table>
                </div>
                <div style="margin-top: 20px;">
                  <el-button type="success" @click="newOk('userNew')" size="small">保存方案</el-button>
                  <el-button type="success" @click="loading()" size="small">导出分析数据</el-button>
                </div>
                <div id="charts" style="width:100%; height:245px; margin-top:20px;">折线图</div>
              </el-col>
            </el-row>
          </div>
          <!-- /.box-body -->
        </div>
        <!-- /.box -->

      </section>
      <!-- /.content -->
      <Spin size="large" fix v-if="spinShow"></Spin>
    </div>

  </transition>

</template>
<script>
var echarts = require('echarts')
export default {
  name: 'linear-analysis',
  data () {
    return {
      rlz: '热力站',
      startDate: '',
      endDate: '',
      checked: '',
      taskList: [],
      rlzs: [
        {
          value: '热力站',
          label: '热力站'
        }
      ],
      zq: '秒',
      zqs: [
        {
          value: 's',
          label: '秒'
        },
        {
          value: 'm',
          label: '分'
        },
        {
          value: 'h',
          label: '小时'
        },
        {
          value: 'd',
          label: '天'
        },
        {
          value: 'mo',
          label: '月'
        },
        {
          value: 'y',
          label: '年'
        }
      ],
      data: [
        {
          label: '基础信息',
          children: [
            {
              key: 'mz',
              label: '面积'
            },
            {
              label: '区域'
            },
            {
              label: '官网长度'
            },
            {
              label: '所属热源'
            }
          ]
        },
        {
          label: '收费指标',
          children: [
            {
              label: '收费总额'
            },
            {
              label: '收费类型'
            },
            {
              label: '退费总额'
            },
            {
              label: '见面总额'
            }
          ]
        },
        {
          label: '生产指标',
          children: [
            {
              label: '热力站',
              children: [
                {
                  key: 'ycrkwd',
                  label: '一次入口温度'
                },
                {
                  key: 'ycyl',
                  label: '一次压力'
                }
              ]
            }
          ]
        },
        {
          label: '客服指标'
        }
      ],
      tableData: [
        {
          id: '1',
          bs: 'hrhzgg',
          dx: '华润海中国三期',
          lx: '热力站'
        },
        {
          id: '2',
          bs: 'dhjxhc',
          dx: '大华锦绣华城',
          lx: '热力站'
        },
        {
          id: '3',
          bs: 'dhsyeq',
          dx: '大湖山语二期',
          lx: '热力站'
        }
      ],
      defaultProps: {
        children: 'children',
        label: 'label'
      },
      highlightCurrent: true,
      defaultExpandAll: true,
      charts: '',
      wd: '',
      yl: '',
      yAxisList: [],
      seriesList: [],
      legendData: [],
      option: {
        tooltip: {
          trigger: 'axis'
        },
        grid: {
          left: '1%',
          right: '4%',
          bottom: '3%',
          containLabel: true
        },
        // 保存图片
        // toolbox: {
        //   feature: {
        //     saveAsImage: {}
        //   }
        // },
        xAxis: {
          type: 'category',
          data: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun']
        },
        legend: {
          data: []
        },
        yAxis: [],
        dataZoom: [
          {
            type: 'slider',
            show: true,
            xAxisIndex: [0],
            start: 50,
            end: 100
          },
          {
            type: 'inside',
            xAxisIndex: [0]
          }
        ],
        series: []
      }
    }
  },
  mounted () {
    this.initTask()
  },
  methods: {
    newOk (data) {
      let taskId = new Date().getTime()
      this.taskList.splice(0, 0, {
        id: taskId,
        name: 'Task-' + taskId
      })
    },
    handleNodeClick (data) {
      console.log(data.key + this.yAxisList.length)
      this.charts = echarts.init(document.getElementById('charts'))
      if (data.key === 'ycrkwd') {
        if (this.yAxisList.length === 0) {
          this.yAxisList.push({
            type: 'value',
            name: '温度',
            position: 'left',
            min: 0,
            max: 100
          })
          this.seriesList.push({
            name: '温度(℃)',
            type: 'line',
            smooth: true,
            data: [21, 15, 2, 33, 28, 88, 21]
          })
          this.legendData.push({
            name: '温度(℃)',
            icon: 'roundRect'
          })
        } else {
          var isH = 0
          for (var i = 0; i < this.yAxisList.length; i++) {
            console.log(data.key + this.yAxisList.length + 1)
            if (this.yAxisList[i].name === '温度') {
              console.log(data.key + this.yAxisList.length + 2)
              isH = 1
              this.yAxisList.splice(i, 1)
              this.seriesList.splice(i, 1)
              this.legendData.splice(i, 1)
              break
            }
          }
          if (isH === 0) {
            this.yAxisList.push({
              type: 'value',
              name: '温度',
              position: 'left',
              min: 0,
              max: 100
            })
            this.seriesList.push({
              name: '温度(℃)',
              type: 'line',
              smooth: true,
              data: [21, 15, 2, 33, 28, 88, 21]
            })
            this.legendData.push({
              name: '温度(℃)',
              icon: 'roundRect'
            })
          }
        }
      }
      if (data.key === 'ycyl') {
        console.log(this.yAxisList.length)
        if (this.yAxisList.length === 0) {
          this.yAxisList.push({
            type: 'value',
            name: '压力',
            position: 'right',
            offset: 0,
            min: 0,
            max: 100
          })
          this.seriesList.push({
            name: '压力(Kpa)',
            type: 'line',
            smooth: true,
            data: [12, 10, 10, 13, 90, 23, 0]
          })
          this.legendData.push({
            name: '压力(Kpa)',
            icon: 'roundRect'
          })
        } else {
          var isHyl = 0
          console.log(this.yAxisList.length)
          for (var m = 0; m < this.yAxisList.length; m++) {
            console.log(this.yAxisList[m].name)
            if (this.yAxisList[m].name === '压力') {
              isHyl = 1
              this.yAxisList.splice(m, 1)
              this.seriesList.splice(m, 1)
              this.legendData.splice(m, 1)
              break
            }
          }
          if (isHyl === 0) {
            this.yAxisList.push({
              type: 'value',
              name: '压力',
              position: 'right',
              offset: 0,
              min: 0,
              max: 100
            })
            this.seriesList.push({
              name: '压力(Kpa)',
              type: 'line',
              smooth: true,
              data: [12, 10, 10, 13, 90, 23, 0]
            })
            this.legendData.push({
              name: '压力(Kpa)',
              icon: 'roundRect'
            })
          }
        }
      }
      this.option.yAxis = this.yAxisList
      this.option.series = this.seriesList
      this.option.legend.data = this.legendData
      this.charts.setOption(this.option, true)
      if (this.yAxisList.length === 0) {
        alert(1)
        // charts.clear
        alert(2)
      }
    },
    initTask () {
      this.$axios({
        method: 'GET',
        url:
          this.global.serverPathScsDI +
          this.global.url.parameters.getTasks,
        params: {}
      })
        .then(
          function (response) {
            this.taskList = response.data.datas
          }.bind(this)
        )
        .catch(function (error) {
          console.log(error)
        })
    }
  }
}
</script>
