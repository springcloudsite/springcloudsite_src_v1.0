<template>
  <div>

    <el-row>
      <el-col :span="6">
        <div>
          <el-tree ref="indexTree" :data="treeOption.indexDatas" node-key="id" :props="treeOption.defaultProps" @check-change="handleCheckChange" check-on-click-node highlight-current default-expand-all></el-tree>
        </div>
      </el-col>
      <el-col :span="18">
        <el-button type="primary" @click="1">选择数据</el-button>
        <scs-table class="mtb20" ref="tableOption11" :table-option="tableOption11"></scs-table>
        <el-button type="primary" @click="1">执行分析</el-button>
        <el-button type="primary" @click="1">保存参数</el-button>
        <el-form ref="form" :model="form" class="mt20">
          <el-input type="textarea" :rows="7" v-model="form.desc"></el-input>
        </el-form>
        <h3>分析结果</h3>
        <el-form ref="form" :model="form">
          <el-input type="textarea" v-model="form.desc"></el-input>
        </el-form>
      </el-col>
    </el-row>
  </div>
</template>
<script>
import ScsTable from '../../commons/ScsTable.vue'
import TypeSelector from './parametersetting/TypeSelector.vue'
import TimeSelector from './parametersetting/TimeSelector.vue'

export default {
  name: 'benchmarking-analysis',
  components: {
    'scs-table': ScsTable,
    'type-selector': TypeSelector,
    'time-selector': TimeSelector
  },
  data () {
    let data = {
      objectType: '1',
      objectTypes: [],
      treeOption: {
        indexDatas: [],
        defaultProps: {
          children: 'children',
          label: 'label'
        }
      },
      form: {
        name: '',
        region: '',
        date1: '',
        date2: '',
        delivery: false,
        type: [],
        resource: '',
        desc: ''
      },
      tableOption11: {
        // showNum: true,
        columns: [
          {
            prop: 'type1',
            label: '调节'
          },
          {
            prop: 'type2',
            label: '温度'
          },
          {
            prop: 'type3',
            label: '外温'
          }
        ],
        datas: [
          {
            type1: '温度',
            type2: '24',
            type3: '25'
          },
          {
            type1: '压力',
            type2: '23',
            type3: '25'
          },
          {
            type1: '流量',
            type2: '234',
            type3: '232'
          },
          {
            type1: '热量',
            type2: '121',
            type3: '153'
          },
          {
            type1: '外温度',
            type2: '-22',
            type3: '-43'
          },
          {
            type1: '单耗',
            type2: '12',
            type3: '11'
          },
          {
            type1: '温度',
            type2: '24',
            type3: '25'
          },
          {
            type1: '温度',
            type2: '24',
            type3: '25'
          },
          {
            type1: '温度',
            type2: '24',
            type3: '25'
          },
          {
            type1: '温度',
            type2: '24',
            type3: '25'
          },
          {
            type1: '温度',
            type2: '24',
            type3: '25'
          }
        ]
      },
      tableOptionCompany: {
        showSelection: true,
        showNum: true,
        columns: [
          {
            prop: 'id',
            label: '对象编号'
          },
          {
            prop: 'objectName',
            label: '对象名称'
          },
          {
            prop: 'objectType',
            label: '对象类型'
          }
        ],
        datas: []
      },
      tableOptionAnalysis: {
        columns: [],
        datas: []
      },
      taskList: [],
      indexSelector: {
        open: false,
        indexCheck: '',
        indexType: ''
      },
      showAnalysisTable: false
    }
    return data
  },
  mounted () {
    this.initPageData()
  },
  methods: {
    initPageData () {
      this.initObjectType()
      this.initIndexTree()
      this.initCompanyTable()
      this.initTask()
    },
    initObjectType () {
      this.$axios({
        method: 'GET',
        url:
          this.global.serverPathScsDI +
          this.global.url.parameters.getObjectType,
        params: {}
      })
        .then(
          function (response) {
            this.objectTypes = response.data.datas
            if (!this.objectType) {
              if (this.objectTypes.length > 0) {
                this.objectTypeChange(this.objectTypes[0].id)
              }
            }
          }.bind(this)
        )
        .catch(function (error) {
          console.log(error)
        })
    },
    initIndexTree () {
      this.$axios({
        method: 'GET',
        url:
          this.global.serverPathScsDI +
          this.global.url.parameters.getFunctionTree,
        data: {
          objectType: this.objectType
        }
      })
        .then(
          function (response) {
            this.treeOption.indexDatas = response.data.datas
          }.bind(this)
        )
        .catch(function (error) {
          console.log(error)
        })
    },
    initCompanyTable () {
      this.$axios({
        method: 'GET',
        url:
          this.global.serverPathScsDI +
          this.global.url.parameters.getCompanyTable,
        data: {
          objectType: this.objectType
        }
      })
        .then(
          function (response) {
            this.tableOptionCompany.datas = response.data.datas
          }.bind(this)
        )
        .catch(function (error) {
          console.log(error)
        })
    },
    initTask () {
      this.$axios({
        method: 'GET',
        url: this.global.serverPathScsDI + this.global.url.parameters.getTasks,
        params: {}
      })
        .then(
          function (response) {
            this.taskList = response.data.datas
          }.bind(this)
        )
        .catch(function (error) {
          console.log(error)
        })
    },
    showTaskDetails (event) {
      let _this = event.toElement
      console.log($(_this).attr('data-id'))
    },
    handleCheckChange (data, checked, childChecked) {
      let node = this.$refs.indexTree.getNode(data.id)
      if (!node.isLeaf) {
        return
      }
      if (checked) {
        let d = {
          id: data.id,
          indexType: data.indexType || 'index',
          indexName: data.label,
          parameterName: '',
          operator: '',
          parameterValue: '',
          unit: '',
          ifShow: true
        }
        this.tableOption.datas.push(d)
      } else {
        let datas = this.tableOption.datas
        for (let i = 0, count = datas.length; i < count; i++) {
          if (datas[i].id === data.id) {
            datas.splice(i, 1)
            break
          }
        }
      }
    },
    handleTypeSelector () {
      let value = {}
      switch (this.indexSelector.indexType) {
        case 'time': {
          value = this.$refs.timeSelector.getValue()
          break
        }
        default: {
          value = this.$refs.typeSelector.getValue()
        }
      }
      let datas = this.tableOption.datas
      for (let i = 0, count = datas.length; i < count; i++) {
        if (datas[i].id === this.indexSelector.indexCheck) {
          datas[i].parameterName = value.index
          datas[i].operator = value.operator
          datas[i].parameterValue = value.value
          datas[i].unit = value.unit
          break
        }
      }
      console.log(this.tableOption.datas)
      this.indexSelector.open = false
    },
    runAnalysis () {
      let tDatas = this.$refs.parameterTable.getTableDatas()
      let companys = this.$refs.companyTable.getCheckDatas()
      let count = tDatas.length
      if (count < 1) {
        this.$message.error('请选择指标')
        return
      }
      if (companys.length < 1) {
        this.$message.error('请选择对标数据')
        return
      }
      let showDatas = []
      let data = null
      for (let i = 0; i < count; i++) {
        data = tDatas[i]
        if (data.ifShow) {
          showDatas.push({
            id: data.id,
            indexType: data.indexType,
            indexName: data.indexName,
            parameterName: data.parameterName,
            operator: data.operator,
            parameterValue: data.parameterValue,
            unit: data.unit
          })
        }
      }
      if (showDatas.length > 0) {
        this.$axios({
          method: 'post',
          url:
            this.global.serverPathScsDI +
            this.global.url.parameters.runBenchmarkingAnalisys,
          data: {
            indexs: showDatas,
            companys: companys
          }
        })
          .then(
            function (response) {
              this.tableOptionAnalysis = response.data.datas
            }.bind(this)
          )
          .catch(function (error) {
            console.log(error)
          })
        let taskId = new Date().getTime()
        this.taskList.splice(0, 0, {
          id: taskId,
          name: 'Task-' + taskId
        })
        this.showAnalysisTable = true
      } else {
        this.$message.error('请选择要显示的指标')
      }
    },
    objectTypeChange (curValue) {
      console.log(curValue)
      this.initIndexTree()
    }
  }
}
</script>
