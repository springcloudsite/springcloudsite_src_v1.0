<style>
.txt-red{
  font-size: 12px;
  color: red;
  margin-top: 10px;
}
</style>
<template>

  <transition name="el-zoom-in-center">

    <div class="content-wrapper">
      <!-- <section class="content-header">
        <ol class="breadcrumb">
          <li>
            <router-link to="/">
              <i class="ti-home"></i>
            </router-link>
          </li>
          <li>
            <a href="#">Forms </a>
          </li>
          <li class="active">Input</li>
        </ol>
      </section> -->

      <!-- Main content -->
      <section>
        <!-- Default box -->
        <div class="box">
          <div class="box-body">
            <el-form :inline="true" :model="formInline" class="demo-form-inline">
              <el-form-item label="名称：">
                <el-input v-model="formInline.user" placeholder="名称"></el-input>
              </el-form-item>
              <el-form-item label="类型：">
                <el-select v-model="formInline.region" placeholder="类型">
                  <el-option label="生产" value="shegnchan"></el-option>
                  <el-option label="管理" value="guanli"></el-option>
                  <el-option label="客服" value="kefu"></el-option>
                </el-select>
              </el-form-item>
              <el-form-item>
                <el-button type="primary" @click="onSubmit">查询</el-button>
              </el-form-item>
            </el-form>
            <el-row :gutter="20">
              <el-col :span="24">
                <el-table :data="tableData">
                  <el-table-column prop="id" label="ID" width="180"></el-table-column>
                  <el-table-column prop="name" label="方案名" width="180"></el-table-column>
                  <el-table-column prop="describe" label="方案描述"></el-table-column>
                  <el-table-column prop="type1" label="方案类型"></el-table-column>
                  <el-table-column prop="type2" label="分析类型"></el-table-column>
                  <el-table-column prop="operate" label="操作">
                    <template slot-scope="scope">
                        <el-button type="text" @click="dialogFormVisible = true">查看</el-button>
                        <el-button type="text" size="small">编辑</el-button>
                        <el-button type="text" size="small">删除</el-button>
                    </template>
                  </el-table-column>
                </el-table>
                <div class="txt-red">说明：查看直接查看最后一次生成的结果</div>
              </el-col>
            </el-row>
          </div>
          <!-- /.box-body -->
        </div>
        <!-- /.box -->

      </section>
      <!-- /.content -->
      <Spin size="large" fix v-if="spinShow"></Spin>
    </div>

  </transition>

</template>
<script>
export default {
  data () {
    return {
      formInline: {
        user: '',
        region: ''
      },
      tableData: [{
        id: 'sel-001',
        name: '分析设备',
        describe: '文思海辉地下',
        type1: '管理',
        type2: '智能分析'
      }, {
        id: 'com-001',
        name: '分析丢水',
        describe: '周水子机场,热力站分析',
        type1: '生产',
        type2: '对标分析'
      }, {
        id: 'com-002',
        name: '分析丢热',
        describe: '周水子机场',
        type1: '生产',
        type2: '对标分析'
      }, {
        id: 'line-001',
        name: '分析单耗大',
        describe: '分析温度不达标',
        type1: '生产',
        type2: '线性分析'
      }, {
        id: 'line-002',
        name: '分析耗电量大',
        describe: '正常均值下分析不对',
        type1: '生产',
        type2: '线性分析'
      }, {
        id: 'sel-001',
        name: '分析设备老化',
        describe: '周水子机场',
        type1: '生产',
        type2: '智能分析'
      }]
    }
  }
}
</script>
