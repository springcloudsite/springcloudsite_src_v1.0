<style>
.mb20{
    margin-bottom: 20px;
}
</style>
<template>
<div class="box">
    <div class="box-body">
        <el-row class="mb20" :gutter="20">
            <el-col :span="6">
                对象类型:
                <el-select v-model="objType" style="width:120px;" size="small">
                <el-option v-for="item in objTypes" :key="item.value" :label="item.label" :value="item.value"></el-option>
                </el-select>
            </el-col>
            <el-col :span="6">
                名称:
                <el-input style="width:200px;" placeholder="请输入内容" v-model="searchName" clearable size="small"></el-input>
            </el-col>
            <el-col :span="2">
                <el-button round @click="search()" size="small">查询</el-button>
            </el-col>
            <el-col :span="2">
                <el-button round @click="dialogFormVisible = true" size="small">添加</el-button>
            </el-col>
        </el-row>
        <el-row :gutter="20">
            <el-table :data="tableData" border style="width: 100%">
                <el-table-column prop="id1" label="ID"></el-table-column>
                <el-table-column prop="id2" label="指标名称"></el-table-column>
                <el-table-column prop="id3" label="指标描述"></el-table-column>
                <el-table-column prop="id4" label="参数选择器"></el-table-column>
                <el-table-column prop="id5" label="类型"></el-table-column>
                <el-table-column prop="id6" label="REST地址"></el-table-column>
                <el-table-column prop="id7" label="对象"></el-table-column>
                <el-table-column label="操作">
                    <template slot-scope="scope">
                        <el-button type="text" @click="dialogFormVisible = true">查看</el-button>
                        <el-button type="text" @click="dialogFormVisible = true">编辑</el-button>
                    </template>
                </el-table-column>
            </el-table>
        </el-row>
        <el-dialog title="指标管理" :visible.sync="dialogFormVisible">
            <div>
              <el-form :inline="true" :model="formInline" class="demo-form-inline">
                <el-form-item label="指标名称：  " >
                  <el-input placeholder="请输入内容" style="width:520px;"></el-input>
                </el-form-item>
                <el-form-item label="指标描述：  ">
                  <el-input placeholder="请输入内容" style="width:520px;"></el-input>
                </el-form-item>
                <el-form-item label="参数选择器：">
                  <el-input placeholder="请输入内容" style="width:520px;"></el-input>
                </el-form-item>
                 <el-form-item label="类型：">
                  <el-input placeholder="请输入内容" style="width:520px;"></el-input>
                </el-form-item>
                <el-form-item label="REST地址： ">
                  <el-input placeholder="请输入内容" style="width:520px;"></el-input>
                </el-form-item>
                <el-form-item label="对象：     ">
                  <el-input placeholder="请输入内容" style="width:520px;"></el-input>
                </el-form-item>
               </el-form>
            </div>
            <div slot="footer" class="dialog-footer">
                <el-button @click="dialogFormVisible = false">取 消</el-button>
                <el-button type="primary" @click="dialogFormVisible = false">确 定</el-button>
            </div>
        </el-dialog>
    </div>
</div>
</template>

<script type="text/javascript">
export default {
  name: 'index-management',
  methods: {
    search (a) {
      this.tableData = [ {
        id1: '1',
        id2: '耗热当年同比翻倍',
        id3: '耗热当年同比翻倍描述',
        id4: '无',
        id5: '自定义',
        id6: '/custom',
        id7: '热力站'
      }, {
        id1: '2',
        id2: '耗热当年同比翻倍',
        id3: '耗热当年同比翻倍描述2',
        id4: '无',
        id5: '自定义',
        id6: '/custom',
        id7: '热力站'
      }]
    },
    editDtl (row) {
      console.log(row)
    }
  },
  data () {
    return {
      objType: '全部',
      searchName: '',
      objTypes: [
        {
          value: '全部',
          label: '全部'
        },
        {
          value: '指标名称',
          label: '指标名称'
        }, {
          value: '指标描述',
          label: '指标描述'
        }, {
          value: '参数选择器',
          label: '参数选择器'
        }, {
          value: '类型',
          label: '类型'
        }, {
          value: 'REST地址',
          label: 'REST地址'
        }, {
          value: '对象',
          label: '对象'
        }
      ],
      tableData: [{
        id1: '1',
        id2: '面积',
        id3: '面积描述',
        id4: '无',
        id5: '基本信息',
        id6: '/baseinfo',
        id7: '热力站'
      }, {
        id1: '2',
        id2: '区域',
        id3: '区域描述',
        id4: '无',
        id5: '基本信息',
        id6: '/baseinfo',
        id7: '热力站'
      }, {
        id1: '3',
        id2: '管网长度',
        id3: '管网长度描述',
        id4: '年代选择器',
        id5: '基本信息',
        id6: '/baseinfo',
        id7: '热力站'
      }, {
        id1: '4',
        id2: '所属热源',
        id3: '所属热源描述',
        id4: '热源类型',
        id5: '基本信息',
        id6: '/baseinfo',
        id7: '热力站'
      }, {
        id1: '5',
        id2: '收费总额',
        id3: '收费总额描述',
        id4: '收费时间段',
        id5: '收费指标',
        id6: 'http://127.0.0.1/charge',
        id7: '热力站'
      }, {
        id1: '6',
        id2: '收费类型',
        id3: '收费类型描述',
        id4: '收费类型选择器',
        id5: '收费指标',
        id6: 'http://127.0.0.1/charge',
        id7: '热力站'
      }, {
        id1: '7',
        id2: '耗热当年同比翻倍',
        id3: '耗热当年同比翻倍描述',
        id4: '无',
        id5: '自定义',
        id6: '/custom',
        id7: '热力站'
      }, {
        id1: '8',
        id2: '耗热当年同比翻倍',
        id3: '耗热当年同比翻倍描述2',
        id4: '无',
        id5: '自定义',
        id6: '/custom',
        id7: '热力站'
      }],
      dialogFormVisible: false,
      form: {
        name: '',
        region: '',
        date1: '',
        date2: '',
        delivery: false,
        type: [],
        resource: '',
        desc: ''
      }
    }
  }
}
</script>
