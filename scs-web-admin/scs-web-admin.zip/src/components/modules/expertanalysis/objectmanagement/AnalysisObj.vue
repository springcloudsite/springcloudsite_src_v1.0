<template>
  <div>
    <el-row>
      <el-col :span="24">
        <el-input placeholder="请输入内容" v-model="searchObject.sValue">
          <el-select class="search-select" v-model="searchObject.sType" slot="prepend" placeholder="请选择">
            <el-option label="对象名称" value="1"></el-option>
            <el-option label="对象类型名称" value="2"></el-option>
          </el-select>
          <el-button slot="append" icon="el-icon-search" @click="handleSearchObject"></el-button>
        </el-input>
      </el-col>
    </el-row>
    <scs-table ref="tableObject" :table-option="tableOption"></scs-table>
  </div>
</template>

<script>
import ScsTable from '../../../commons/ScsTable.vue'
export default {
  name: 'analysis-object',
  components: {
    'scs-table': ScsTable
  },
  data () {
    let _that = this
    return {
      tableOption: {
        showNum: true,
        // showSelection: true,
        columns: [
          {
            prop: 'businessid',
            label: '业务唯一主键'
          },
          {
            prop: 'name',
            label: '对象名称'
          },
          {
            prop: 'objectType',
            label: '对象类型'
          },
          {
            prop: 'description',
            label: '对象描述'
          },
          {
            prop: 'founder',
            label: '创建人'
          },
          {
            prop: 'action',
            label: '操作',
            renderCell: function (h, scope) {
              let row = scope.row
              return h('div', [
                h(
                  'el-button',
                  {
                    props: {
                      size: 'mini',
                      type: 'primary'
                    },
                    on: {
                      click: () => {
                        _that.loadModifyPage(row.id)
                      }
                    }
                  },
                  '编辑'
                ),
                h(
                  'el-button',
                  {
                    props: {
                      size: 'mini',
                      type: 'danger'
                    },
                    on: {
                      click: () => {
                        _that.removeObjectInfo(row.id)
                      }
                    }
                  },
                  '删除'
                )
              ])
            }
          }
        ],
        datas: [],
        dataUrl:
          this.global.serverPathScsDI +
          this.global.url.scsObject.getPagerObjectsBySearch,
        isPager: true,
        buttons: [
          {
            code: 'add',
            click: function () {
              _that.$router.push({ path: '/object-base' })
            }
          }
        ],
        pager: {
          sort: 'id.asc'
        },
        searchParams: {}
      },
      searchObject: {
        sValue: '',
        sType: '1'
      }
    }
  },
  methods: {
    removeObjectInfo (id) {
      this.$confirm(
        this.$t('commons.messages.deleteConfirm'),
        this.$t('commons.titles.info'),
        {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }
      )
        .then(() => {
          this.$axios({
            method: 'DELETE',
            url:
              this.global.serverPathScsDI +
              this.global.url.scsObject.deleteObjectById,
            urlParams: {
              id: id
            }
          })
            .then(
              function (response) {
                this.$message({
                  message: this.$t('commons.messages.deleteSuccess'),
                  type: 'success'
                })
                this.handleSearchObject()
              }.bind(this)
            )
            .catch(function (error) {
              console.log(error)
            })
        })
        .catch(() => {
          console.log('cancel delete')
        })
    },
    handleSearchObject () {
      switch (this.searchObject.sType) {
        case '1': {
          this.tableOption.searchParams = {
            nameLike: this.searchObject.sValue
          }
          break
        }
        case '2': {
          this.tableOption.searchParams = {
            objectTypeLike: this.searchObject.sValue
          }
          break
        }
      }
      this.$refs.tableObject.initPageData()
    },
    loadModifyPage (id) {
      this.$router.push({ path: '/object-base', query: { id: id } })
    }
  }
}
</script>
<style scoped>
.search-select {
  width: 140px;
}
</style>
