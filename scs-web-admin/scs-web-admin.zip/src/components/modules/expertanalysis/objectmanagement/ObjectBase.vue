<template>
  <transition>
    <div>
      <el-form :model="formObject" :rules="rulesObject" ref="formObject" label-width="150px">
        <el-form-item label="对象名称" prop="name">
          <el-input v-model="formObject.name" placeholder="请输入对象名称"></el-input>
        </el-form-item>
        <el-form-item label="业务唯一主键" prop="businessid">
          <el-input v-model="formObject.businessid" placeholder="请输入业务唯一主键"></el-input>
        </el-form-item>
        <el-form-item label="详细描述" prop="description">
          <el-input v-model="formObject.description" placeholder="请输入详细描述"></el-input>
        </el-form-item>
        <el-form-item label="对象类型" prop="typeid">
          <el-select v-model="formObject.typeid" placeholder="请输入对象类型">
            <el-option v-for="objectType in objectTypes" :key="objectType.id" :label="objectType.name" :value="objectType.id"> </el-option>
          </el-select>
        </el-form-item>
        <el-form-item>
          <el-button type="primary" @click="submitForm()">保存</el-button>
          <el-button @click="resetForm()">重置</el-button>
        </el-form-item>
      </el-form>
    </div>
  </transition>
</template>
<script>
export default {
  name: 'object-base',
  components: {},
  data () {
    let _isNotChinese = this.customValidates('isNotChinese')
    let data = {
      formObject: {
        id: this.$route.query.id || '',
        name: '',
        businessid: '',
        description: '',
        typeid: ''
      },
      objectTypes: [],
      rulesObject: {
        name: [
          {
            required: true,
            message: '对象名称不能为空',
            trigger: ['blur', 'change']
          },
          {
            max: 100,
            message: '长度不能超过100字符',
            trigger: ['blur', 'change']
          }
        ],
        businessid: [
          {
            required: true,
            message: '业务唯一主键不能为空',
            trigger: ['blur', 'change']
          },
          {
            max: 100,
            message: '长度不能超过100字符',
            trigger: ['blur', 'change']
          },
          { validator: _isNotChinese, trigger: ['blur', 'change'] }
        ],
        description: [
          {
            required: true,
            message: '详细描述不能为空',
            trigger: ['blur', 'change']
          },
          {
            max: 250,
            message: '长度不能超过250字符',
            trigger: ['blur', 'change']
          }
        ],
        typeid: [
          {
            required: true,
            message: '对象类型不能为空',
            trigger: ['blur', 'change']
          }
        ]
      }
    }
    return data
  },
  watch: {
    // roleId (cur, old) {
    //   this.initObjectData()
    // }
  },
  mounted () {
    this.initPageData()
  },
  methods: {
    initPageData () {
      this.initObjectTypeData()
      this.initObjectData()
    },
    initObjectTypeData () {
      this.$axios({
        method: 'GET',
        url:
          this.global.serverPathScsDI +
          this.global.url.objectType.getAllObjectTypes
      })
        .then(
          function (response) {
            let _data = response.data
            this.objectTypes = _data
          }.bind(this)
        )
        .catch(function (error) {
          console.log(error)
        })
    },
    initObjectData () {
      // 初始化数据
      let _objectId = this.formObject.id
      if (_objectId) {
        this.$axios({
          method: 'GET',
          url:
            this.global.serverPathScsDI +
            this.global.url.scsObject.getObjectById,
          urlParams: {
            id: _objectId
          }
        })
          .then(
            function (response) {
              let _data = response.data
              this.formObject = _data
              this.isTabDisable = false
            }.bind(this)
          )
          .catch(function (error) {
            console.log(error)
          })
      }
    },
    submitForm () {
      // 保存表单信息
      this.$refs.formObject.validate(valid => {
        if (valid) {
          let _data = {
            id: this.formObject.id,
            name: this.formObject.name,
            businessid: this.formObject.businessid,
            description: this.formObject.description,
            typeid: this.formObject.typeid
          }

          let _url = this.global.serverPathScsDI
          let _type = ''
          if (_data.id) {
            _url = _url + this.global.url.scsObject.modifyObject
            _type = 'PATCH'
          } else {
            _url = _url + this.global.url.scsObject.newObject
            _type = 'POST'
          }
          this.$axios({
            method: _type,
            url: _url,
            data: _data
          })
            .then(
              function (response) {
                this.$message({
                  message: this.$t('commons.messages.saveSuccess'),
                  type: 'success'
                })
                this.formObject.id = response.data.id
                this.isTabDisable = false
              }.bind(this)
            )
            .catch(
              function (error) {
                console.log(error)
                this.showValidateMsg(this.$refs.formObject, error, this)
              }.bind(this)
            )
        } else {
          console.log('error submit!!')
          return false
        }
      })
    },
    resetForm () {
      // 重置表单
      this.$refs.formObject.resetFields()
    }
  }
}
</script>
<style scoped>
</style>
