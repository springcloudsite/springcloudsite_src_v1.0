<template>
  <transition name="fade" mode="out-in">
    <el-form :model="timeForm" label-width="160px">
      <el-form-item label="日期范围">
        <el-col :span="11">
          <el-date-picker type="date" placeholder="选择开始日期" v-model="timeForm.date1" style="width: 100%;"></el-date-picker>
        </el-col>
        <el-col class="line" :span="2">-</el-col>
        <el-col :span="11">
          <el-date-picker type="date" placeholder="选择结束日期" v-model="timeForm.date2" style="width: 100%;"></el-date-picker>
        </el-col>
      </el-form-item>
      <el-form-item label="参数">
        <el-select v-model="timeForm.index" placeholder="请选择参数">
          <el-option label="SUM" value="SUM"></el-option>
          <el-option label="AVG" value="AVG"></el-option>
          <el-option label="MAX" value="MAX"></el-option>
          <el-option label="MIN" value="MIN"></el-option>
          <el-option label="FIRST" value="FIRST"></el-option>
          <el-option label="LAST" value="LAST"></el-option>
        </el-select>
      </el-form-item>
      <el-form-item label="运算符">
        <el-select v-model="timeForm.operator" placeholder="请选择运算符">
          <el-option label="无运算符" value=""></el-option>
          <el-option label=">" value=">"></el-option>
          <el-option label="<" value="<"></el-option>
          <el-option label="=" value="="></el-option>
          <el-option label="包含" value="包含"></el-option>
          <el-option label="不包含" value="不包含"></el-option>
        </el-select>
      </el-form-item>
      <el-form-item label="数值">
        <el-input v-model="timeForm.value" placeholder="请输入数值"></el-input>
      </el-form-item>
      <el-form-item label="单位">
        <el-select v-model="timeForm.unit" placeholder="请选择单位">
          <el-option label="万㎡" value="万㎡"></el-option>
          <el-option label="GJ" value="GJ"></el-option>
          <el-option label="T" value="T"></el-option>
          <el-option label="%" value="%"></el-option>
        </el-select>
      </el-form-item>
    </el-form>
  </transition>
</template>
<script>
export default {
  name: 'time-selector',
  data () {
    let data = {
      timeForm: {}
    }
    return data
  },
  mounted () {},
  methods: {
    getValue () {
      return this.timeForm
    }
  }
}
</script>
