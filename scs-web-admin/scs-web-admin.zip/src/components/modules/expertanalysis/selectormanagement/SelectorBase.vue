<template>
  <transition>
    <div>
      <el-form :model="formSelector" :rules="rulesSelector" ref="formSelector" label-width="150px">
        <el-form-item label="选择器名称" prop="name">
          <el-input v-model="formSelector.name" placeholder="请输入选择器名称"></el-input>
        </el-form-item>
        <el-form-item label="选择器地址" prop="urlpath">
          <el-input v-model="formSelector.urlpath" placeholder="请输入选择器地址"></el-input>
        </el-form-item>
        <el-form-item>
          <el-button type="primary" @click="submitForm()">保存</el-button>
          <el-button @click="resetForm()">重置</el-button>
        </el-form-item>
      </el-form>
    </div>
  </transition>
</template>
<script>
export default {
  name: 'selector-base',
  components: {},
  data () {
    let data = {
      formSelector: {
        id: this.$route.query.id || '',
        name: '',
        urlpath: ''
      },
      rulesSelector: {
        name: [
          {
            required: true,
            message: '选择器名称不能为空',
            trigger: ['blur', 'change']
          },
          {
            max: 100,
            message: '长度不能超过100字符',
            trigger: ['blur', 'change']
          }
        ],
        urlpath: [
          {
            required: true,
            message: '选择器地址不能为空',
            trigger: ['blur', 'change']
          },
          {
            max: 250,
            message: '长度不能超过250字符',
            trigger: ['blur', 'change']
          }
        ]
      }
    }
    return data
  },
  watch: {
    // roleId (cur, old) {
    //   this.initSelectorData()
    // }
  },
  mounted () {
    this.initPageData()
  },
  methods: {
    initPageData () {
      this.initSelectorData()
    },
    initSelectorData () {
      // 初始化数据
      let _selectorId = this.formSelector.id
      if (_selectorId) {
        this.$axios({
          method: 'GET',
          url:
            this.global.serverPathScsDI +
            this.global.url.selector.getSelectorById,
          urlParams: {
            id: _selectorId
          }
        })
          .then(
            function (response) {
              let _data = response.data
              this.formSelector = _data
            }.bind(this)
          )
          .catch(function (error) {
            console.log(error)
          })
      }
    },
    submitForm () {
      // 保存表单信息
      this.$refs.formSelector.validate(valid => {
        if (valid) {
          let _data = {
            id: this.formSelector.id,
            name: this.formSelector.name,
            urlpath: this.formSelector.urlpath
          }

          let _url = this.global.serverPathScsDI
          let _type = ''
          if (_data.id) {
            _url = _url + this.global.url.selector.modifySelector
            _type = 'PATCH'
          } else {
            _url = _url + this.global.url.selector.newSelector
            _type = 'POST'
          }
          this.$axios({
            method: _type,
            url: _url,
            data: _data
          })
            .then(
              function (response) {
                this.$message({
                  message: this.$t('commons.messages.saveSuccess'),
                  type: 'success'
                })
                this.formSelector.id = response.data.id
              }.bind(this)
            )
            .catch(
              function (error) {
                console.log(error)
                this.showValidateMsg(this.$refs.formSelector, error, this)
              }.bind(this)
            )
        } else {
          console.log('error submit!!')
          return false
        }
      })
    },
    resetForm () {
      // 重置表单
      this.$refs.formSelector.resetFields()
    }
  }
}
</script>
<style scoped>
</style>
