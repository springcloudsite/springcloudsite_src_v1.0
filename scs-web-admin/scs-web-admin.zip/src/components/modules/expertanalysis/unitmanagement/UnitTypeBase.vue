<template>
  <transition>
    <div>
      <el-form :model="formUnitType" :rules="rulesUnitType" ref="formUnitType" label-width="150px">
        <el-form-item label="单位类型名称" prop="name">
          <el-input v-model="formUnitType.name" placeholder="请输入单位类型名称"></el-input>
        </el-form-item>
        <el-form-item>
          <el-button type="primary" @click="submitForm()">保存</el-button>
          <el-button @click="resetForm()">重置</el-button>
        </el-form-item>
      </el-form>
    </div>
  </transition>
</template>
<script>
export default {
  name: 'unit-type-base',
  components: {},
  data () {
    let data = {
      formUnitType: {
        id: this.$route.query.id || '',
        name: ''
      },
      rulesUnitType: {
        name: [
          {
            required: true,
            message: '单位类型名称不能为空',
            trigger: ['blur', 'change']
          },
          {
            max: 100,
            message: '长度不能超过100字符',
            trigger: ['blur', 'change']
          }
        ]
      }
    }
    return data
  },
  watch: {
    // roleId (cur, old) {
    //   this.initUnitTypeData()
    // }
  },
  mounted () {
    this.initPageData()
  },
  methods: {
    initPageData () {
      this.initUnitTypeData()
    },
    initUnitTypeData () {
      // 初始化数据
      let _unitTypeId = this.formUnitType.id
      if (_unitTypeId) {
        this.$axios({
          method: 'GET',
          url:
            this.global.serverPathScsDI +
            this.global.url.unitType.getUnitTypeById,
          urlParams: {
            id: _unitTypeId
          }
        })
          .then(
            function (response) {
              let _data = response.data
              this.formUnitType = _data
            }.bind(this)
          )
          .catch(function (error) {
            console.log(error)
          })
      }
    },
    submitForm () {
      // 保存表单信息
      this.$refs.formUnitType.validate(valid => {
        if (valid) {
          let _data = {
            id: this.formUnitType.id,
            name: this.formUnitType.name
          }

          let _url = this.global.serverPathScsDI
          let _type = ''
          if (_data.id) {
            _url = _url + this.global.url.unitType.modifyUnitType
            _type = 'PATCH'
          } else {
            _url = _url + this.global.url.unitType.newUnitType
            _type = 'POST'
          }
          this.$axios({
            method: _type,
            url: _url,
            data: _data
          })
            .then(
              function (response) {
                this.$message({
                  message: this.$t('commons.messages.saveSuccess'),
                  type: 'success'
                })
                this.formUnitType.id = response.data.id
              }.bind(this)
            )
            .catch(
              function (error) {
                console.log(error)
                this.showValidateMsg(this.$refs.formUnitType, error, this)
              }.bind(this)
            )
        } else {
          console.log('error submit!!')
          return false
        }
      })
    },
    resetForm () {
      // 重置表单
      this.$refs.formUnitType.resetFields()
    }
  }
}
</script>
<style scoped>
</style>
