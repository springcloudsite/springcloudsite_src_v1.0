<template>
  <transition>
    <div>
      <el-row>
        <el-col :span="24">
          <el-form label-width="150px">
            <el-form-item label="父级节点">
              <span>{{formFunction.parentFtnName}}</span>
            </el-form-item>
          </el-form>
        </el-col>
      </el-row>
      <el-form :model="formFunction" :rules="rulesFunction" ref="formFunction" label-width="150px">
        <el-form-item label="资源类型" prop="functionType">
          <el-select v-model="formFunction.functionType" placeholder="请选择资源类型">
            <el-option label="菜单" value="1"></el-option>
            <el-option label="按钮" value="2"></el-option>
            <el-option label="接口" value="3"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="资源编码" prop="functionCode">
          <el-input v-model="formFunction.functionCode" placeholder="请输入资源编码(唯一标识)"></el-input>
        </el-form-item>
        <el-form-item label="资源名称" prop="functionName">
          <el-input v-model="formFunction.functionName" placeholder="请输入资源名称"></el-input>
        </el-form-item>
        <el-form-item label="详细描述" prop="functionDescription">
          <el-input v-model="formFunction.functionDescription" placeholder="请输入详细描述" type="textarea"></el-input>
        </el-form-item>
        <el-form-item label="资源图标" prop="icon">
          <el-input v-model="formFunction.icon" placeholder="请输入图标样式"></el-input>
        </el-form-item>
        <el-form-item label="资源路由地址" prop="url">
          <el-input v-model="formFunction.url" placeholder="请输入路由地址"></el-input>
        </el-form-item>
        <el-form-item label="显示顺序">
          <el-input-number v-model="formFunction.showSort" :min="0" :max="99999"></el-input-number>
        </el-form-item>
        <el-form-item label="是否可用">
          <el-switch v-model="formFunction.isDisable" active-value='0' inactive-value='1' active-text="启用" inactive-text="禁用"></el-switch>
        </el-form-item>
        <el-form-item>
          <el-button type="primary" @click="submitForm()">保存</el-button>
          <el-button @click="resetForm()">重置</el-button>
        </el-form-item>
      </el-form>
    </div>
  </transition>
</template>
<script>
export default {
  name: 'function-base',
  props: ['functionId'],
  data () {
    let _valIsNotChinese = this.customValidates('isNotChinese')
    let data = {
      formFunction: {
        id: '',
        parentId: '',
        parentFtnName: '无',
        functionType: '',
        functionCode: '',
        functionName: '',
        functionDescription: '',
        url: '',
        icon: '',
        showSort: '0',
        isDisable: '0'
      },
      rulesFunction: {
        functionType: [
          {
            required: true,
            message: '资源类型不能为空',
            trigger: ['blur', 'change']
          }
        ],
        functionCode: [
          {
            required: true,
            message: '资源编码不能为空',
            trigger: ['blur', 'change']
          },
          {
            max: 40,
            message: '长度不能超过40字符',
            trigger: ['blur', 'change']
          },
          { validator: _valIsNotChinese, trigger: ['blur', 'change'] }
        ],
        functionName: [
          {
            required: true,
            message: '资源名称不能为空',
            trigger: ['blur', 'change']
          },
          {
            max: 50,
            message: '长度不能超过50字符',
            trigger: ['blur', 'change']
          }
        ],
        functionDescription: [
          {
            max: 100,
            message: '长度不能超过100字符',
            trigger: ['blur', 'change']
          }
        ],
        icon: [
          {
            max: 50,
            message: '长度不能超过50字符',
            trigger: ['blur', 'change']
          }
        ],
        url: [
          {
            max: 200,
            message: '长度不能超过200字符',
            trigger: ['blur', 'change']
          }
        ]
      }
    }
    return data
  },
  watch: {
    // functionId (cur, old) {
    //   this.initFunctionData()
    // }
  },
  mounted () {
    this.initPageData()
  },
  methods: {
    initPageData () {
      this.initFunctionData()
    },
    initFunctionData (ftnId) {
      // 初始化数据
      let _ftnId = ftnId || this.functionId
      if (_ftnId) {
        this.$axios({
          method: 'GET',
          url: this.global.serverPathUser + this.global.url.functions.getFunctionById,
          urlParams: {
            id: _ftnId
          }
        })
          .then(
            function (response) {
              let _data = response.data
              this.formFunction = _data
              this.formFunction.parentFtnName = _data.parentFtnName || '无'
            }.bind(this)
          )
          .catch(function (error) {
            console.log(error)
          })
      }
    },
    newFunctionPage (isRoot) {
      // 新建页面初始化数据
      this.formFunction = {
        id: '',
        parentId: '',
        parentFtnName: '无',
        functionType: '',
        functionCode: '',
        functionName: '',
        functionDescription: '',
        icon: '',
        showSort: '0',
        isDisable: '0'
      }
      this.resetForm()
      let _ftnId = isRoot ? '' : this.functionId
      if (_ftnId) {
        this.$axios({
          method: 'GET',
          url: this.global.serverPathUser + this.global.url.functions.getFunctionById,
          urlParams: {
            id: _ftnId
          }
        })
          .then(
            function (response) {
              let _data = response.data
              this.formFunction.parentId = _data.id
              this.formFunction.parentFtnName = _data.functionName || '无'
            }.bind(this)
          )
          .catch(function (error) {
            console.log(error)
          })
      }
    },
    editFunctionPage (ftnId) {
      // 初始化编辑数据
      this.initFunctionData(ftnId)
    },
    submitForm () {
      // 保存表单信息
      this.$refs.formFunction.validate(valid => {
        if (valid) {
          let _data = {
            id: this.formFunction.id,
            parentId: this.formFunction.parentId,
            functionType: this.formFunction.functionType,
            functionCode: this.formFunction.functionCode,
            functionName: this.formFunction.functionName,
            functionDescription: this.formFunction.functionDescription,
            url: this.formFunction.url,
            icon: this.formFunction.icon,
            showSort: this.formFunction.showSort,
            isDisable: this.formFunction.isDisable
          }

          let _url = this.global.serverPathUser
          let _type = ''
          if (_data.id) {
            _url = _url + this.global.url.functions.modifyFunction
            _type = 'PATCH'
          } else {
            _url = _url + this.global.url.functions.newFunction
            _type = 'POST'
          }
          this.$axios({
            method: _type,
            url: _url,
            data: _data
          })
            .then(
              function (response) {
                this.$message({
                  message: this.$t('commons.messages.saveSuccess'),
                  type: 'success'
                })
                this.formFunction.id = response.data.id
                this.$emit('refreshMenuTree')
              }.bind(this)
            )
            .catch(function (error) {
              console.log(error)
              this.showValidateMsg(this.$refs.formFunction, error, this)
            }.bind(this))
        } else {
          console.log('error submit!!')
          return false
        }
      })
    },
    resetForm () {
      // 重置表单
      this.$refs.formFunction.resetFields()
    }
  }
}
</script>
<style scoped>
</style>
