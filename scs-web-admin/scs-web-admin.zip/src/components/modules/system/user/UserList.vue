<template>
  <transition>
    <div>
      <el-row>
        <el-col :span="24">
          <el-input placeholder="请输入内容" v-model="searchUser.sValue">
            <el-select class="search-select" v-model="searchUser.sType" slot="prepend" placeholder="请选择">
              <el-option label="登录名称" value="1"></el-option>
              <el-option label="用户昵称" value="2"></el-option>
            </el-select>
            <el-button slot="append" icon="el-icon-search" @click="handleSearchUser"></el-button>
          </el-input>
        </el-col>
      </el-row>
      <scs-table ref="tableUser" :table-option="tableOption"></scs-table>
    </div>
  </transition>
</template>
<script>
import ScsTable from '../../../commons/ScsTable.vue'
export default {
  name: 'user-list',
  components: {
    'scs-table': ScsTable
  },
  data () {
    let _that = this
    let data = {
      tableOption: {
        // showNum: true,
        showSelection: true,
        columns: [
          {
            prop: 'loginName',
            label: '登录名称'
          },
          {
            prop: 'nickname',
            label: '用户昵称'
          },
          {
            prop: 'isDisable',
            label: '是否可用',
            renderCell: function (h, scope) {
              let row = scope.row
              return h('el-switch', {
                attrs: {
                  value: row.isDisable
                },
                props: {
                  'active-value': '0',
                  'inactive-value': '1'
                },
                on: {
                  input: value => {
                    let _msg =
                      value === '1' ? '是否要禁用该用户？' : '是否启用该用户？'
                    _that
                      .$confirm(_msg, _that.$t('commons.titles.info'), {
                        confirmButtonText: '确定',
                        cancelButtonText: '取消',
                        type: 'warning'
                      })
                      .then(() => {
                        _that.modifyUserInfo({ id: row.id, isDisable: value })
                      })
                      .catch(() => {
                        console.log('cancel delete')
                      })
                  }
                }
              })
            }
          },
          {
            prop: 'isDelete',
            label: '是否删除',
            renderCell: function (h, scope) {
              let row = scope.row
              return h('el-switch', {
                attrs: {
                  value: row.isDelete
                },
                props: {
                  'active-value': '1',
                  'inactive-value': '0'
                },
                on: {
                  input: value => {
                    _that
                      .$confirm(
                        _that.$t('commons.messages.deleteConfirm'),
                        _that.$t('commons.titles.info'),
                        {
                          confirmButtonText: '确定',
                          cancelButtonText: '取消',
                          type: 'warning'
                        }
                      )
                      .then(() => {
                        _that.modifyUserInfo({ id: row.id, isDelete: value })
                      })
                      .catch(() => {
                        console.log('cancel delete')
                      })
                  }
                }
              })
            }
          },
          {
            prop: 'action',
            label: '操作',
            renderCell: function (h, scope) {
              let row = scope.row
              return h('div', [
                h(
                  'el-button',
                  {
                    props: {
                      size: 'mini',
                      type: 'primary'
                    },
                    on: {
                      click: () => {
                        _that.loadModifyPage(row.id)
                      }
                    }
                  },
                  '编辑'
                ),
                h(
                  'el-button',
                  {
                    props: {
                      size: 'mini',
                      type: 'danger'
                    },
                    on: {
                      click: () => {
                        _that.resetPassword(row.id)
                      }
                    }
                  },
                  '重置密码'
                  // ),
                  // h(
                  //   'el-button',
                  //   {
                  //     props: {
                  //       size: 'mini',
                  //       type: 'danger'
                  //     },
                  //     on: {
                  //       click: () => {
                  //         _that.removeUserInfo(row.id)
                  //       }
                  //     }
                  //   },
                  //   '删除'
                )
              ])
            }
          }
        ],
        datas: [],
        dataUrl:
          this.global.serverPathUser +
          this.global.url.user.getPagerUndeletedUsersBySearch,
        isPager: true,
        buttons: [
          {
            code: 'add',
            click: function () {
              _that.$router.push({ path: '/user-base' })
            }
          }
        ],
        pager: {
          sort: 'id.asc'
        },
        searchParams: {}
      },
      searchUser: {
        sValue: '',
        sType: '1'
      }
    }
    return data
  },
  watch: {},
  mounted () {
    this.initPageData()
  },
  methods: {
    initPageData () {},
    handleSearchUser () {
      switch (this.searchUser.sType) {
        case '1': {
          this.tableOption.searchParams = {
            loginNameLike: this.searchUser.sValue
          }
          break
        }
        case '2': {
          this.tableOption.searchParams = {
            nicknameLike: this.searchUser.sValue
          }
        }
      }
      this.$refs.tableUser.initPageData()
    },
    loadModifyPage (id) {
      this.$router.push({ path: '/user-base', query: { id: id } })
    },
    modifyUserInfo (user) {
      this.$axios({
        method: 'PATCH',
        url: this.global.serverPathUser + this.global.url.user.modifyUser,
        data: user
      })
        .then(
          function (response) {
            this.$message({
              message: this.$t('commons.messages.modifySuccess'),
              type: 'success'
            })
            this.handleSearchUser()
          }.bind(this)
        )
        .catch(
          function (error) {
            console.log(error)
            this.$message({
              message: this.$t('commons.messages.failedAction'),
              type: 'error'
            })
            this.handleSearchUser()
          }.bind(this)
        )
    },
    removeUserInfo (id) {
      this.$confirm(
        this.$t('commons.messages.deleteConfirm'),
        this.$t('commons.titles.info'),
        {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }
      )
        .then(() => {
          this.$axios({
            method: 'DELETE',
            url:
              this.global.serverPathUser + this.global.url.user.deleteUserById,
            urlParams: {
              id: id
            }
          })
            .then(
              function (response) {
                this.$message({
                  message: this.$t('commons.messages.deleteSuccess'),
                  type: 'success'
                })
                this.handleSearchUser()
              }.bind(this)
            )
            .catch(
              function (error) {
                console.log(error)
                this.handleSearchUser()
              }.bind(this)
            )
        })
        .catch(() => {
          console.log('cancel delete')
        })
    },
    resetPassword (userId) {
      this.$confirm('确定重置该用户密码吗？', this.$t('commons.titles.info'), {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      })
        .then(() => {
          this.$axios({
            method: 'PATCH',
            url:
              this.global.serverPathUser + this.global.url.user.resetPassword,
            urlParams: {
              id: userId
            }
          })
            .then(
              function (response) {
                this.$message({
                  message: '密码重置成功',
                  type: 'success'
                })
                this.handleSearchUser()
              }.bind(this)
            )
            .catch(
              function (error) {
                console.log(error)
                this.handleSearchUser()
              }.bind(this)
            )
        })
        .catch(() => {
          console.log('cancel reset password')
        })
    }
  }
}
</script>
<style scoped>
.search-select {
  width: 120px;
}
</style>
