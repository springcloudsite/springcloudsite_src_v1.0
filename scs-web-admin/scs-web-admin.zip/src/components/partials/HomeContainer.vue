<template>
  <transition>
    <div>
      <scs-header></scs-header>
      <router-view :menu-tree="homeMenu" :cur-menu="curMenu"></router-view>
      <scs-footer></scs-footer>
    </div>
  </transition>
</template>

<script>
import Header from './Header.vue'
import Footer from './Footer.vue'

export default {
  name: 'home-container',
  components: {
    'scs-header': Header,
    'scs-footer': Footer
  },
  data () {
    let data = {
      isCollapse: false,
      homeMenu: [],
      homeMenuMap: {},
      curMenu: {}
    }
    return data
  },
  beforeRouteEnter (to, from, next) {
    console.log('home-beforeRouteEnter')
    // 在渲染该组件的对应路由被 confirm 前调用
    // 不！能！获取组件实例 `this`
    // 因为当钩子执行前，组件实例还没被创建
    next()
  },
  watch: {
    // curMenu: {
    //   handler (curVal, oldVal) {
    //     this.$router.push({ path: curVal.path, hash: curVal.uuid })
    //   }
    // }
  },
  created () {
    console.log('app-created')
    this.$axios({
      method: 'GET',
      url: this.global.serverPathUser + this.global.url.functions.getMenuByOrigin
    })
      .then(
        function (response) {
          let _routes = response.data
          let _menus = this.initRouteMenu(_routes, {id: null})
          this.homeMenu = _menus
          let _hash = location.hash
          if (_hash) {
            this.curMenu = this.homeMenuMap[_hash.substring(2)]
          }
        }.bind(this)
      )
      .catch(function (error) {
        console.log(error)
      })
  },
  mounted () {
    let _this = this
    this.$root.$on('getMenuById', function (id) {
      _this.curMenu = _this.homeMenuMap[id.substring(1)]
    })
    this.initPageData()
  },
  methods: {
    initPageData () {},
    onSubmit () {
      console.log('submit!')
    },
    initRouteMenu (menus, parent) {
      let _rootMenus = []
      menus = menus || []
      if (menus.length < 1) {
        return _rootMenus
      }
      let menu = {}
      let _menus = []
      for (let i = 0, count = menus.length; i < count; i++) {
        menu = menus[i]
        if (menu.parentId === parent.id) {
          let m = this.initMenu(menu)
          this.homeMenuMap[menu.id] = m
          _rootMenus.push(m)
        } else {
          _menus.push(menu)
        }
      }
      for (let i = 0, count = _rootMenus.length; i < count; i++) {
        _rootMenus[i].children = this.initRouteMenu(_menus, _rootMenus[i])
        _rootMenus[i].leaf = _rootMenus[i].children.length === 0
      }
      return _rootMenus
    },
    initMenu (menu) {
      let _menu = {
        id: menu.id,
        uuid: 'M' + menu.id,
        code: menu.functionCode,
        name: menu.functionName,
        path: !menu.url ? '/' + menu.id : menu.url,
        iconCls: menu.icon
      }
      let _matched = this.homeMenuMap[menu.parentId]
      _matched = _matched ? _matched.matched : _matched
      if (!_matched) {
        _matched = [
          {
            id: 'home',
            code: 'home-container',
            name: '首页',
            path: '/home-container',
            iconCls: 'fa fa-align-justify'
          }
        ]
      }
      _matched = [].concat(_matched)
      _matched.push(_menu)
      _menu.matched = _matched
      return _menu
    }
  }
}
</script>

<style scoped lang="scss">
header {
  height: 60px;
}
</style>
