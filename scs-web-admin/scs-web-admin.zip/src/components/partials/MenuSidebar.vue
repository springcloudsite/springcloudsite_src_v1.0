<template>
  <!--导航菜单-->
  <div class="header-tabs" :class="!!menuPrefix ? menuPrefix + '-header-tabs' : ''">
    <div class="menu-tabs" :class="!!menuPrefix ? menuPrefix + '-menu-tabs' : ''">
      <template v-for="menu in menuTree">
        <template v-if="!menu.leaf">
          <a :key="'menu-'+ menu.id" href="javascript:void(0)" @mouseover="tabsMenu(menu.id, 'block')" @mouseout="tabsMenu(menu.id, 'none')">{{menu.name}}</a>
        </template>
        <template v-else>
          <router-link :key="'menu-'+ menu.id" :to="menu.path">
            {{menu.name}}
          </router-link>
        </template>
      </template>
    </div>
    <template v-for="menu in menuTree">
      <template v-if="!menu.leaf">
        <div :key="'menu-bg-' + menu.id" class="box-bg" :id="menu.id" @mouseover="tabsMenu(menu.id, 'block');" @mouseout="tabsMenu(menu.id, 'none')">
          <div class="tabs-name" width="100%">
            <template v-for="menu2nd in menu.children">
              <template v-if="!menu2nd.leaf">
                <div :key="'menu-2nd-' + menu2nd.id" class="tabs-lu">
                  {{menu2nd.name}}
                </div>
                <div class="tabs-li" v-for="menu3rd in menu2nd.children" :key="'menu-3rd-' + menu3rd.id">
                  <router-link :to="menu3rd.path">
                    {{menu3rd.name}}
                  </router-link>
                </div>
              </template>
              <template v-else>
                <div :key="'menu-2nd-' + menu2nd.id" class="tabs-li">
                  <router-link :to="menu2nd.path">
                    {{menu2nd.name}}
                  </router-link>
                </div>
              </template>
            </template>
          </div>
        </div>
      </template>
    </template>
  </div>
</template>
<script>
import ScsSubMenu from './ScsSubMenu.vue'
export default {
  name: 'menu-sidebar',
  components: { 'scs-sub-menu': ScsSubMenu },
  props: ['menuTree', 'curMenu', 'menuPrefix'],
  data () {
    let data = {}
    return data
  },
  watch: {
    curMenu: {
      handler (curVal, oldVal) {
        this.$router.push({ path: curVal.path, hash: curVal.uuid })
      }
    }
  },
  mounted: function () {},
  methods: {
    handleopen () {
      // console.log('handleopen');
    },
    handleclose () {
      // console.log('handleclose');
    },
    handleselect: function (index, paths) {
      this.$root.$emit('getMenuById', index)
    },
    tabsMenu (obj, sType) {
      let _oDiv = document.getElementById(obj)
      if (_oDiv) {
        _oDiv.style.display = sType
      }
    }
  }
}
</script>
<style scoped lang="scss">
.tabs-name {
  display: flex;
  font-size: 12px;
  line-height: 2.5em;
  // white-space: nowrap;
  flex-wrap: wrap;
}
.tabs-li {
  box-sizing: border-box;
  white-space: normal;
  word-wrap: break-word;
  word-break: break-all;
  // display: inline-block;
  width: 200px;
}
.menu-tabs {
  font-size: 12px;
  padding: 0 30px;
  border-top: #a5a5a5 1px solid;
  border-bottom: #a5a5a5 1px solid;
}
.menu-tabs a {
  color: #fff;
  font-weight: bold;
  text-decoration: none;
  padding-right: 50px;
  padding-bottom: 15px;
  line-height: 42px;
  font-size: 12px;
}
.menu-tabs a:hover {
  color: #00c1de;
}
.header-tabs {
  position: absolute;
  top: 0;
  left: 0;
  z-index: 10;
  width: 100%;
}
.header-tabs .box-bg {
  max-width: 800px;
  background-color: #fff;
  display: none;
  padding: 15px 30px;
}
.header-tabs .box-bg a{
  color: #333333;
  text-decoration: none;
}
.header-tabs .box-bg a:hover{
  color: #00c1de;
}
</style>
<style scoped lang="scss">
.main-menu-tabs a {
  color: #333333;
}
.main-menu-tabs a:hover {
  color: #00c1de;
}
.main-header-tabs {
  top: 60px;
  background-color: #f9f9f9;
}
.main-header-tabs .box-bg {
  max-width: 800px;
  background-color: #f9f9f9;
  display: none;
  padding: 15px 30px;
}
</style>
