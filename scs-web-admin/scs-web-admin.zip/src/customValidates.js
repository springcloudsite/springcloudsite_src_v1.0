let customValidate = function (type, param) {
  // 自定义校验方法
  let fn = null
  switch (type) {
    case 'confirmPwd':
    {
      fn = (rule, value, callback) => {
        var confirm = $('#' + param.confirm).val()
        if (confirm) {
          if (value === confirm) {
            callback()
            param.validate(param.confirm)
          } else {
            callback(new Error('密码与确认密码不一致'))
          }
        } else {
          callback()
          param.validate(param.confirm)
        }
      }
      break
    }
    case 'isNotChinese':
    {
      fn = (rule, value, callback) => {
        var reg = new RegExp('^[a-zA-Z0-9]+[-#\\w]*$')
        if (reg.test(value)) {
          callback()
        } else {
          callback(new Error('请输入字母、数字、"#"、"-"或"_"，以数字或字母开始'))
        }
      }
      break
    }
    case 'numOrLetter':
    {
      fn = (rule, value, callback) => {
        var reg = new RegExp('^[A-Za-z0-9]+$')
        if (reg.test(value)) {
          callback()
        } else {
          callback(new Error('请输入字母或数字'))
        }
      }
      break
    }
    case 'isPhone':
    {
      fn = (rule, value, callback) => {
        var reg = new RegExp('^((13[0-9])|(14[5-9])|(15([0-3]|[5-9]))|(16(6))|(17[0-1,3,5-7])|(18[0-9])|(19[8-9]))\\d{8}$')
        if (reg.test(value)) {
          callback()
        } else {
          callback(new Error('请输入正确的手机号'))
        }
      }
      break
    }
    case 'isNumber':
    {
      fn = (rule, value, callback) => {
        var reg = /^([0-9]{1,9}|[0-9]{1,9}\.[0-9]{1,2})$/
        if (reg.test(value)) {
          callback()
        } else {
          if (value) {
            callback(new Error('长度不能超过9位'))
          } else {
            callback(new Error('请输入商务报价'))
          }
        }
      }
      break
    }
    case 'idCode':
    {
      fn = (rule, value, callback) => {
        // 15位和18位身份证号码的正则表达式
        var pass = true
        var reg = /(^\d{15}$)|(^\d{18}$)|(^\d{17}(\d|X|x)$)/
        if (reg.test(value) === false) {
          pass = false
        } else {
          pass = true
        }
        if (pass) {
          callback()
        } else {
          callback(new Error('请输入正确的身份证号'))
        }
      }
      break
    }
    case 'dateNotNull':
    {
      fn = (rule, value, callback) => {
        if (value) {
          callback()
        } else {
          callback(new Error())
        }
      }
      break
    }
  }
  return fn
}
let showValidateMsg = function (form, error, vm) {
  // 直接显示错误信息
  let result = false
  let _data = error.response.data
  let _validates = _data.invalidMessages
  if (!form || !_validates) {
    vm.$message({
      message: _data.errorMessage,
      type: 'error'
    })
    return result
  }
  let fields = form.fields
  if (fields) {
    let field = null
    for (let i = 0, count = fields.length; i < count; i++) {
      field = fields[i]
      if (_validates[field.prop]) {
        field.validateState = 'error'
        let msg = _validates[field.prop]
        if (vm) {
          msg = vm.$t(_validates[field.prop]) || msg
        }
        field.validateMessage = msg
        result = true
      }
    }
  }
  return result
}
export default {customValidate, showValidateMsg}
