module.exports = {
  message: {
    title: 'Sport Brands'
  },
  placeholder: {
    enter: 'Please type in your favorite brand'
  },
  brands: {
    nike: 'Nike',
    adi: 'Adidas',
    nb: 'New Banlance',
    ln: 'LI Ning'
  },
  lang: {
    toggle: 'are you sure toggle language?',
    ok: 'ok',
    cancel: 'cancel',
    tips: 'tips'
  },

  FormInputVal: {
    loginname: 'loginname',
    username: 'username',
    password: 'password',
    confirmpass: 'confirmpass',
    checks: 'checks',
    email: 'email'
  },
  exception: {
    userrepeat: 'user repeat'
  }
}
