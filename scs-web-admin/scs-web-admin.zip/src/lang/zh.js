module.exports = {
  commons: { // 通用配置
    messages: { // 通用消息提示
      saveSuccess: '保存成功',
      modifySuccess: '修改成功',
      deleteSuccess: '删除成功',
      deleteConfirm: '确认要删除选中信息吗？',
      failedAction: '操作失败',
      TODO: '建设中...'
    },
    validateRules: { // 通用校验规则提示
      notNull: '{0}不能为空',
      min: '长度不能小于{0}',
      max: '长度不能大于{0}'
    },
    titles: {
      info: '提示'
    },
    buttons: {
      add: '添加',
      edit: '编辑',
      del: '删除'
    }
  }
}
