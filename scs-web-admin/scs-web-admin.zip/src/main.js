import Vue from 'vue'
import ElementUI from 'element-ui' //  for element 2.4.7 below
// import 'element-ui/lib/theme-default/index.css'
import 'element-ui/lib/theme-chalk/index.css'
import Resource from 'vue-resource'
import VueRouter from 'vue-router'
import routes from './routes'
import store from './store'
// import VueAxios from 'vue-axios'
import global from './Global'
import VueI18n from 'vue-i18n'
import promise from 'es6-promise'
import axios from './axios'
import 'babel-polyfill'
import App from './App.vue' // Import top level component
import './mock' // 引入mockjs
import customValidates from './customValidates' // 引入自定义扩展校验方法
import userAuthentication from './userAuthentication' // 引入用户登录信息操作

Vue.use(VueI18n)
Vue.use(Resource) // Resource logic
Vue.use(VueRouter)
Vue.use(ElementUI)
// Vue.use(axios)
// Vue.use(VueAxios)
Vue.http.options.emulateJSON = true
Vue.prototype.global = global
Vue.prototype.$axios = axios
Vue.prototype.customValidates = customValidates.customValidate
Vue.prototype.showValidateMsg = customValidates.showValidateMsg
Vue.prototype.userAuthentication = userAuthentication
promise.polyfill()

// 全局异常处理
Vue.prototype.JavaException = function (error) {
  return this.$t(error)
}
// Routing logic  mode:'hash'
// 取消原框架路由定义转到routes.js
// var router = new VueRouter({
//   routes: routes,
//   mode: 'history',
//   linkActiveClass: 'open active',
//   scrollBehavior: function (to, from, savedPosition) {
//     return savedPosition || { x: 0, y: 0 }
//   }
// })
// Check local storage to handle refreshes
if (window.localStorage) {
  if (store.state.token !== window.localStorage.getItem('token')) {
    store.commit('SET_TOKEN', window.localStorage.getItem('token'))
  }
}
const i18n = new VueI18n({
  locale: 'zh', // 语言标识
  messages: {
    'zh': require('./lang/zh'),
    'en': require('./lang/en')
  }
})
// Some middleware to help us ensure the user is authenticated.
// Start out app!
// eslint-disable-next-line no-new
new Vue({
  el: '#app',
  i18n,
  router: routes,
  store: store,
  render: h => h(App)
})
