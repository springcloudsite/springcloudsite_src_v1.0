let getCookieByKey = function (key) {
  // 根据key值取得cookie中的值
  let reg = new RegExp('(^| )' + key + '=([^;]*)(;|$)')
  let arr = document.cookie.match(reg)
  if (arr) {
    return unescape(arr[2])
  } else {
    return ''
  }
}
let userAuthentication = function () {
  function getStore () {
    let obj = window.sessionStorage.getItem('user-info')
    if (obj) {
      obj = JSON.parse(obj)
    } else {
      obj = {}
    }
    return obj
  }
  let _obj = getStore()
  let _auth = {
    userId: _obj.userId || '',
    loginName: _obj.loginName || '',
    nickname: _obj.nickname || '',
    isHasRole: function (roleCodes) {
      // 判断是否存在角色
      let isHas = false
      let roles = _obj.roles
      if (roles) {
        let _roleCodes = roleCodes || []
        let _count = _roleCodes.length
        for (let i = 0, count = roles.length; i < count; i++) {
          for (let j = 0; j < _count; j++) {
            if (roles[i] === _roleCodes[j]) {
              isHas = true
              break
            }
          }
        }
      }
      return isHas
    },
    checkToken: function () {
      // 判断是否登录
      let _r = !!getCookieByKey('user-token')
      if (!_r) {
        this.clearUser()
      }
      return _r
    },
    saveUser: function (user) {
      // 记录用户信息
      user = user || {}
      window.sessionStorage.setItem('user-info', JSON.stringify(user))
      _obj = user
    },
    clearUser: function () {
      window.sessionStorage.removeItem('user-info')
      // 清除登录信息
      let exp = new Date()
      exp.setTime(exp.getTime() - 1)
      document.cookie = 'user-token=;expires=' + exp.toGMTString()
      document.cookie = 'user-token=;domain=tgcw.net.cn;expires=' + exp.toGMTString()
      // // 刷新header登录信息
      // vm.$root.$emit('headerToShowUser')
    }
  }
  return _auth
}
export default userAuthentication
